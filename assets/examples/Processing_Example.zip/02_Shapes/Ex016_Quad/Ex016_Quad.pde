/*
 * Example 016: Quad
 * Draws quadrilaterals (4-sided shapes) using quad().
 * Four corner points define arbitrary four-sided polygons.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(240);
  stroke(0);
  strokeWeight(2);

  // Parallelogram
  fill(100, 180, 220);
  quad(80, 50, 280, 50, 320, 150, 120, 150);

  // Trapezoid
  fill(220, 160, 100);
  quad(100, 200, 300, 200, 350, 300, 50, 300);

  // Irregular quad
  fill(160, 220, 100);
  quad(120, 320, 200, 310, 300, 370, 80, 380);

  fill(0);
  textSize(14);
  text("Parallelogram", 140, 115);
  text("Trapezoid", 160, 265);
  text("Irregular Quad", 150, 358);
}
