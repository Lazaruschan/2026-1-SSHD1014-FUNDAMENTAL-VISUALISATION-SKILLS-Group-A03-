/*
 * Example 017: Arc
 * Draws arcs (partial ellipses) using arc().
 * Shows different arc modes: OPEN, CHORD, and PIE.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(240);
  strokeWeight(2);

  // OPEN arc (default)
  fill(100, 180, 255);
  stroke(0);
  arc(100, 100, 140, 140, 0, HALF_PI + QUARTER_PI, OPEN);

  fill(0);
  textSize(12);
  text("OPEN", 75, 190);

  // CHORD arc
  fill(255, 180, 100);
  arc(300, 100, 140, 140, 0, HALF_PI + QUARTER_PI, CHORD);

  fill(0);
  text("CHORD", 275, 190);

  // PIE arc
  fill(180, 255, 100);
  arc(100, 300, 140, 140, 0, HALF_PI + QUARTER_PI, PIE);

  fill(0);
  text("PIE", 85, 390);

  // Pie chart
  float[] data = {30, 20, 25, 25};
  color[] colors = {
    color(65, 135, 245), color(245, 85, 85),
    color(85, 200, 85), color(245, 200, 65)
  };
  float angle = 0;
  for (int i = 0; i < data.length; i++) {
    float arc_angle = radians(data[i] / 100.0 * 360);
    fill(colors[i]);
    arc(300, 300, 140, 140, angle, angle + arc_angle, PIE);
    angle += arc_angle;
  }

  fill(0);
  text("Pie Chart", 270, 390);
}
