/*
 * Example 018: Custom Shape
 * Uses beginShape() / vertex() / endShape() to draw custom polygons.
 * This lets you create any shape by specifying vertices.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(240);
  stroke(0);
  strokeWeight(2);

  // Star shape
  fill(255, 215, 0);
  beginShape();
  float cx = 120, cy = 120, outer = 70, inner = 30;
  for (int i = 0; i < 10; i++) {
    float angle = TWO_PI / 10 * i - HALF_PI;
    float r = (i % 2 == 0) ? outer : inner;
    vertex(cx + cos(angle) * r, cy + sin(angle) * r);
  }
  endShape(CLOSE);

  // Arrow shape
  fill(100, 149, 237);
  beginShape();
  vertex(280, 60);
  vertex(350, 120);
  vertex(320, 120);
  vertex(320, 180);
  vertex(240, 180);
  vertex(240, 120);
  vertex(210, 120);
  endShape(CLOSE);

  // Organic blob with curveVertex
  fill(200, 100, 150, 180);
  beginShape();
  curveVertex(100, 280);
  curveVertex(100, 280);
  curveVertex(160, 250);
  curveVertex(220, 300);
  curveVertex(180, 360);
  curveVertex(100, 350);
  curveVertex(60, 310);
  curveVertex(100, 280);
  curveVertex(100, 280);
  endShape(CLOSE);

  // Hexagon
  fill(100, 200, 180);
  beginShape();
  for (int i = 0; i < 6; i++) {
    float angle = TWO_PI / 6 * i - HALF_PI;
    vertex(310 + cos(angle) * 60, 310 + sin(angle) * 60);
  }
  endShape(CLOSE);
}
