/*
 * Example 014: Ellipse
 * Draws ellipses and circles with ellipse() and circle().
 * Demonstrates ellipseMode() options.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(240);

  // Circle
  fill(100, 149, 237);
  stroke(0);
  circle(100, 100, 120);

  fill(0);
  textSize(12);
  text("circle()", 75, 175);

  // Ellipse (oval)
  fill(237, 149, 100);
  ellipse(300, 100, 160, 80);

  fill(0);
  text("ellipse()", 270, 160);

  // Concentric rings
  noFill();
  strokeWeight(2);
  for (int i = 5; i > 0; i--) {
    stroke(i * 50, 100, 255 - i * 40);
    ellipse(200, 300, i * 60, i * 60);
  }
}
