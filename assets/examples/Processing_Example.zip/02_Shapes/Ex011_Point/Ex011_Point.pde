/*
 * Example 011: Point
 * Draws individual points (pixels) on the canvas.
 * Demonstrates the simplest drawing primitive.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(255);
  stroke(0);
  strokeWeight(4);

  // Draw a grid of points
  for (int x = 50; x <= 350; x += 20) {
    for (int y = 50; y <= 350; y += 20) {
      point(x, y);
    }
  }
}
