/*
 * Example 013: Rectangle
 * Draws rectangles with rect() and demonstrates rectMode().
 * Shows CORNER mode (default) vs CENTER mode.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(240);

  // Default CORNER mode: (x, y) is top-left
  rectMode(CORNER);
  fill(100, 149, 237);
  stroke(0);
  rect(30, 30, 150, 100);

  fill(0);
  textSize(12);
  text("CORNER mode", 35, 155);

  // CENTER mode: (x, y) is center of rectangle
  rectMode(CENTER);
  fill(237, 100, 100);
  rect(300, 80, 150, 100);

  fill(0);
  text("CENTER mode", 230, 155);

  // Rounded rectangle
  rectMode(CORNER);
  fill(100, 200, 100);
  rect(30, 200, 340, 80, 20);

  fill(0);
  text("Rounded corners (radius 20)", 40, 310);

  // Square shortcut
  fill(255, 200, 50);
  square(150, 330, 50);

  fill(0);
  text("square()", 150, 395);
}
