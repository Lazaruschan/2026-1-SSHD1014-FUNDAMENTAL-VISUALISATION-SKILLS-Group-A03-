/*
 * Example 012: Line
 * Draws lines between pairs of coordinates.
 * Shows how to use stroke() and strokeWeight().
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(255);

  // Thin black line
  stroke(0);
  strokeWeight(1);
  line(50, 50, 350, 50);

  // Thick red line
  stroke(255, 0, 0);
  strokeWeight(4);
  line(50, 120, 350, 120);

  // Fan of lines from bottom-left corner
  strokeWeight(1);
  for (int i = 0; i <= 10; i++) {
    float t = i / 10.0;
    stroke(lerpColor(color(0, 100, 255), color(255, 50, 50), t));
    line(50, 350, 50 + i * 30, 180);
  }
}
