/*
 * Example 015: Triangle
 * Draws triangles using three pairs of coordinates.
 * Shows different triangle types and a tessellation pattern.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(240);
  stroke(0);

  // Equilateral-ish triangle
  fill(100, 200, 150);
  triangle(200, 30, 100, 180, 300, 180);

  // Right triangle
  fill(200, 100, 150);
  triangle(30, 220, 30, 370, 170, 370);

  // Triangle tessellation
  float tileW = 40;
  float tileH = 35;
  for (int row = 0; row < 4; row++) {
    for (int col = 0; col < 5; col++) {
      float x = 200 + col * tileW;
      float y = 220 + row * tileH;
      fill((col + row) % 2 == 0 ? color(70, 130, 230) : color(230, 180, 70));
      triangle(x, y, x + tileW, y, x + tileW / 2, y + tileH);
      fill((col + row) % 2 == 0 ? color(230, 180, 70) : color(70, 130, 230));
      triangle(x + tileW / 2, y, x + tileW, y + tileH, x + tileW * 1.5, y);
    }
  }
}
