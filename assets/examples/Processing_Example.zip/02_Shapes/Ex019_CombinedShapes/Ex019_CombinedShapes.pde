/*
 * Example 019: Combined Shapes
 * Builds a simple scene (house) by combining basic shapes.
 * Demonstrates how primitives compose into meaningful drawings.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(135, 206, 235);

  // Sun
  fill(255, 220, 50);
  noStroke();
  circle(340, 60, 70);

  // Ground
  fill(100, 180, 80);
  rect(0, 300, 400, 100);

  // House body
  stroke(0);
  strokeWeight(2);
  fill(210, 160, 120);
  rect(100, 200, 200, 120);

  // Roof
  fill(180, 60, 60);
  triangle(80, 200, 200, 100, 320, 200);

  // Door
  fill(120, 80, 50);
  rect(175, 250, 50, 70);

  // Doorknob
  fill(200, 180, 50);
  circle(215, 290, 8);

  // Windows
  fill(180, 220, 255);
  rect(120, 230, 40, 35);
  rect(240, 230, 40, 35);

  // Window cross bars
  stroke(0);
  strokeWeight(1);
  line(140, 230, 140, 265);
  line(120, 247, 160, 247);
  line(260, 230, 260, 265);
  line(240, 247, 280, 247);

  // Chimney
  fill(160, 80, 80);
  noStroke();
  rect(260, 120, 30, 60);
}
