/*
 * Example 020: Shape Grid
 * Draws a grid of shapes that change based on row and column.
 * Demonstrates loops combined with shape drawing.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(30);
  noStroke();

  int cols = 8;
  int rows = 8;
  float cellW = width / (float) cols;
  float cellH = height / (float) rows;

  for (int row = 0; row < rows; row++) {
    for (int col = 0; col < cols; col++) {
      float x = col * cellW + cellW / 2;
      float y = row * cellH + cellH / 2;

      float r = map(col, 0, cols - 1, 50, 255);
      float g = map(row, 0, rows - 1, 50, 255);
      float b = 150;
      fill(r, g, b);

      int shapeType = (row + col) % 3;
      float s = cellW * 0.7;

      if (shapeType == 0) {
        ellipse(x, y, s, s);
      } else if (shapeType == 1) {
        rectMode(CENTER);
        rect(x, y, s, s);
      } else {
        triangle(x, y - s / 2, x - s / 2, y + s / 2, x + s / 2, y + s / 2);
      }
    }
  }
}
