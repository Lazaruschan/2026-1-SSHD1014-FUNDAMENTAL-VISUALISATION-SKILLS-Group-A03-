/*
 * Example 073: Noise Landscape
 * Generates a 2D noise-based terrain visualization.
 * Each pixel's brightness is determined by Perlin noise.
 *
 * Requires: Processing 4.x
 */

float zoff = 0;

void setup() {
  size(400, 400);
  pixelDensity(1);
}

void draw() {
  loadPixels();
  float xoff = 0;
  for (int x = 0; x < width; x++) {
    float yoff = 0;
    for (int y = 0; y < height; y++) {
      float n = noise(xoff, yoff, zoff);
      int bright = (int)(n * 255);

      // Color mapping: water, land, mountain
      color c;
      if (n < 0.35) {
        c = lerpColor(color(20, 30, 80), color(30, 80, 180), n / 0.35);
      } else if (n < 0.6) {
        c = lerpColor(color(30, 120, 30), color(80, 180, 50), (n - 0.35) / 0.25);
      } else {
        c = lerpColor(color(120, 100, 80), color(240, 240, 240), (n - 0.6) / 0.4);
      }
      pixels[x + y * width] = c;
      yoff += 0.01;
    }
    xoff += 0.01;
  }
  updatePixels();
  zoff += 0.005;

  fill(255);
  textSize(14);
  text("Perlin Noise Terrain", 10, 20);
}
