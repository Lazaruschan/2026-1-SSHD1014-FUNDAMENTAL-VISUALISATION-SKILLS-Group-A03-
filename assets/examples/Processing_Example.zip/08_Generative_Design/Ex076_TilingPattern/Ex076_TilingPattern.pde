/*
 * Example 076: Tiling Pattern
 * Generates a random tiling pattern where each cell has a random design.
 * Click to regenerate a new random arrangement.
 *
 * Requires: Processing 4.x
 */

int tileSize = 50;

void setup() {
  size(400, 400);
  generatePattern();
}

void draw() {
}

void mousePressed() {
  generatePattern();
}

void generatePattern() {
  background(240);
  stroke(40);
  strokeWeight(2);

  for (int x = 0; x < width; x += tileSize) {
    for (int y = 0; y < height; y += tileSize) {
      int pattern = (int) random(4);
      drawTile(x, y, pattern);
    }
  }
}

void drawTile(int x, int y, int pattern) {
  noFill();
  switch (pattern) {
    case 0:
      // Diagonal line top-left to bottom-right
      line(x, y, x + tileSize, y + tileSize);
      break;
    case 1:
      // Diagonal line top-right to bottom-left
      line(x + tileSize, y, x, y + tileSize);
      break;
    case 2:
      // Quarter circle from top-left
      arc(x, y, tileSize * 2, tileSize * 2, 0, HALF_PI);
      break;
    case 3:
      // Quarter circle from bottom-right
      arc(x + tileSize, y + tileSize, tileSize * 2, tileSize * 2, PI, PI + HALF_PI);
      break;
  }
}
