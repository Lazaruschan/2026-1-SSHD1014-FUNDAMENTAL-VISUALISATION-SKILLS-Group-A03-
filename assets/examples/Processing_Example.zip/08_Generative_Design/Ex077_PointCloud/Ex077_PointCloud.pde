/*
 * Example 077: Point Cloud
 * Draws thousands of semi-transparent points in a spherical distribution.
 * Demonstrates using trig functions for 3D-like point distributions.
 *
 * Requires: Processing 4.x
 */

float rotY = 0;

void setup() {
  size(400, 400);
}

void draw() {
  background(10);
  translate(width / 2, height / 2);

  int numPoints = 3000;
  float radius = 150;

  for (int i = 0; i < numPoints; i++) {
    // Golden angle distribution on a sphere (projected to 2D)
    float t = (float) i / numPoints;
    float phi = acos(1 - 2 * t);
    float theta = PI * (1 + sqrt(5)) * i + rotY;

    float x = radius * sin(phi) * cos(theta);
    float y = radius * sin(phi) * sin(theta);
    float z = radius * cos(phi);

    // Simple depth cue: points "behind" are dimmer
    float depthFactor = map(z, -radius, radius, 0.2, 1.0);
    float sz = map(z, -radius, radius, 1, 4);

    noStroke();
    fill(100 + depthFactor * 155, 150, 255 - depthFactor * 100, depthFactor * 200);
    circle(x, y, sz);
  }

  rotY += 0.01;
}
