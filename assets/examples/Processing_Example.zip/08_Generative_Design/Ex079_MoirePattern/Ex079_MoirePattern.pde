/*
 * Example 079: Moire Pattern
 * Two sets of concentric circles overlap to create a moire effect.
 * Move the mouse to shift one set and see interference patterns.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
}

void draw() {
  background(255);
  noFill();
  stroke(0, 100);
  strokeWeight(1);

  // Fixed set of concentric circles
  for (int r = 10; r < 500; r += 8) {
    ellipse(width / 2, height / 2, r, r);
  }

  // Moving set following the mouse
  for (int r = 10; r < 500; r += 8) {
    ellipse(mouseX, mouseY, r, r);
  }
}
