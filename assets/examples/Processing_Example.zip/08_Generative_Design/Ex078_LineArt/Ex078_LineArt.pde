/*
 * Example 078: Line Art
 * Creates intricate patterns using lines between mathematical points.
 * Move mouse to change the pattern parameters.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
}

void draw() {
  background(10);
  translate(width / 2, height / 2);

  int numLines = 80;
  float radius = 160;
  float factor = map(mouseX, 0, width, 1, 10);

  stroke(255, 40);
  strokeWeight(1);

  for (int i = 0; i < numLines; i++) {
    float angle1 = TWO_PI / numLines * i;
    float angle2 = TWO_PI / numLines * i * factor;

    float x1 = cos(angle1) * radius;
    float y1 = sin(angle1) * radius;
    float x2 = cos(angle2) * radius;
    float y2 = sin(angle2) * radius;

    stroke(
      map(i, 0, numLines, 50, 255),
      150,
      map(i, 0, numLines, 255, 50),
      60
    );
    line(x1, y1, x2, y2);
  }

  // Outer circle guide
  noFill();
  stroke(60);
  circle(0, 0, radius * 2);
}
