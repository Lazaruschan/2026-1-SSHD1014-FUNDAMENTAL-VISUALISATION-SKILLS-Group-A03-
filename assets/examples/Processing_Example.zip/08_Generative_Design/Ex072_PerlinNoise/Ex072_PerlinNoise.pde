/*
 * Example 072: Perlin Noise
 * Uses noise() for smooth, organic-looking random values.
 * Perlin noise produces more natural patterns than random().
 *
 * Requires: Processing 4.x
 */

float xoff = 0;

void setup() {
  size(400, 400);
}

void draw() {
  background(20);

  // Noise-driven landscape
  stroke(100, 200, 255);
  strokeWeight(2);
  noFill();
  beginShape();
  float off = xoff;
  for (int x = 0; x <= width; x += 3) {
    float y = noise(off) * height * 0.6 + 50;
    vertex(x, y);
    off += 0.02;
  }
  endShape();

  // 2D noise field as dots
  noStroke();
  float yoff = xoff;
  for (int gx = 0; gx < width; gx += 15) {
    float xn = xoff + gx * 0.01;
    for (int gy = 200; gy < height; gy += 15) {
      float n = noise(xn, yoff + gy * 0.01);
      fill(255, n * 255);
      circle(gx, gy, n * 10);
    }
  }

  xoff += 0.01;
}
