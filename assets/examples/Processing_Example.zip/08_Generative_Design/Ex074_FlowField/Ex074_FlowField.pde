/*
 * Example 074: Flow Field
 * Particles follow a Perlin-noise-based vector field.
 * Demonstrates noise-driven direction for organic motion.
 *
 * Requires: Processing 4.x
 */

int numParticles = 800;
float[] px, py;
float noiseScale = 0.005;
float zoff = 0;

void setup() {
  size(400, 400);
  background(20);

  px = new float[numParticles];
  py = new float[numParticles];
  for (int i = 0; i < numParticles; i++) {
    px[i] = random(width);
    py[i] = random(height);
  }
}

void draw() {
  // Slow fade for trail effect
  noStroke();
  fill(20, 10);
  rect(0, 0, width, height);

  for (int i = 0; i < numParticles; i++) {
    float angle = noise(px[i] * noiseScale, py[i] * noiseScale, zoff) * TWO_PI * 2;
    float vx = cos(angle) * 2;
    float vy = sin(angle) * 2;

    stroke(map(px[i], 0, width, 100, 255), 150, map(py[i], 0, height, 255, 100), 40);
    strokeWeight(1);
    point(px[i], py[i]);

    px[i] += vx;
    py[i] += vy;

    // Wrap around
    if (px[i] < 0) px[i] = width;
    if (px[i] > width) px[i] = 0;
    if (py[i] < 0) py[i] = height;
    if (py[i] > height) py[i] = 0;
  }
  zoff += 0.002;
}

void mousePressed() {
  background(20);
  for (int i = 0; i < numParticles; i++) {
    px[i] = random(width);
    py[i] = random(height);
  }
}
