/*
 * Example 080: Cellular Automata
 * Implements a 1D elementary cellular automaton (Rule 30).
 * Each row is computed from the row above, creating complex patterns.
 *
 * Requires: Processing 4.x
 */

int cellSize = 4;
int cols;
int[] cells;
int[] nextCells;
int generation = 0;
int ruleNumber = 30;

void setup() {
  size(400, 400);
  background(255);
  cols = width / cellSize;
  cells = new int[cols];
  nextCells = new int[cols];

  // Seed: single cell in the center
  cells[cols / 2] = 1;
}

void draw() {
  int y = generation * cellSize;
  if (y >= height) {
    noLoop();
    return;
  }

  for (int i = 0; i < cols; i++) {
    if (cells[i] == 1) {
      fill(0);
    } else {
      fill(255);
    }
    noStroke();
    rect(i * cellSize, y, cellSize, cellSize);
  }

  // Compute next generation
  for (int i = 0; i < cols; i++) {
    int left  = (i > 0) ? cells[i - 1] : 0;
    int mid   = cells[i];
    int right = (i < cols - 1) ? cells[i + 1] : 0;
    int index = left * 4 + mid * 2 + right;
    nextCells[i] = (ruleNumber >> index) & 1;
  }

  // Swap
  int[] temp = cells;
  cells = nextCells;
  nextCells = temp;
  generation++;
}

void mousePressed() {
  // Reset with a different rule
  ruleNumber = (int) random(256);
  println("Rule: " + ruleNumber);
  generation = 0;
  background(255);
  cells = new int[cols];
  cells[cols / 2] = 1;
  loop();
}
