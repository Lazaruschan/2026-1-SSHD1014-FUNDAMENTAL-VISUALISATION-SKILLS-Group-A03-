/*
 * Example 075: Recursion Tree
 * Draws a fractal tree using recursive function calls.
 * Each branch splits into two smaller branches.
 *
 * Requires: Processing 4.x
 */

float angleDelta;

void setup() {
  size(400, 400);
}

void draw() {
  background(20);

  angleDelta = map(mouseX, 0, width, 0.1, PI / 3);

  stroke(255);
  translate(width / 2, height);
  branch(100, 8);
}

void branch(float len, int depth) {
  if (depth <= 0) return;

  float weight = map(depth, 0, 8, 1, 5);
  strokeWeight(weight);

  float green = map(depth, 0, 8, 80, 40);
  stroke(80, 120 + green, 60);

  line(0, 0, 0, -len);
  translate(0, -len);

  // Left branch
  pushMatrix();
  rotate(-angleDelta);
  branch(len * 0.72, depth - 1);
  popMatrix();

  // Right branch
  pushMatrix();
  rotate(angleDelta);
  branch(len * 0.72, depth - 1);
  popMatrix();
}
