/*
 * Example 071: Random Walk
 * A dot takes random steps, tracing a wandering path.
 * Demonstrates randomness as a design tool.
 *
 * Requires: Processing 4.x
 */

float x, y;

void setup() {
  size(400, 400);
  background(20);
  x = width / 2;
  y = height / 2;
  strokeWeight(1);
}

void draw() {
  float prevX = x;
  float prevY = y;

  x += random(-4, 4);
  y += random(-4, 4);

  x = constrain(x, 0, width);
  y = constrain(y, 0, height);

  stroke(map(x, 0, width, 50, 255), 100, map(y, 0, height, 255, 50), 80);
  line(prevX, prevY, x, y);
}

void mousePressed() {
  background(20);
  x = width / 2;
  y = height / 2;
}
