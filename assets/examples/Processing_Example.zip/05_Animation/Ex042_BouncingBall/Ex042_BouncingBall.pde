/*
 * Example 042: Bouncing Ball
 * A ball bounces off the edges of the window.
 * Demonstrates velocity and boundary collision.
 *
 * Requires: Processing 4.x
 */

float x, y;
float vx = 4;
float vy = 3;
float radius = 20;

void setup() {
  size(400, 400);
  x = width / 2;
  y = height / 2;
  noStroke();
}

void draw() {
  background(30);

  x += vx;
  y += vy;

  if (x - radius < 0 || x + radius > width) vx *= -1;
  if (y - radius < 0 || y + radius > height) vy *= -1;

  fill(255, 100, 80);
  circle(x, y, radius * 2);
}
