/*
 * Example 047: Fade In/Out
 * A circle fades in and out using sin() to modulate alpha.
 * Demonstrates smooth opacity animation.
 *
 * Requires: Processing 4.x
 */

float angle = 0;

void setup() {
  size(400, 400);
  noStroke();
}

void draw() {
  background(20);

  float alpha = map(sin(angle), -1, 1, 0, 255);

  fill(0, 180, 255, alpha);
  circle(width / 2, height / 2, 200);

  fill(255);
  textSize(14);
  textAlign(CENTER);
  text("Alpha: " + nf(alpha, 1, 0), width / 2, 370);

  angle += 0.03;
}
