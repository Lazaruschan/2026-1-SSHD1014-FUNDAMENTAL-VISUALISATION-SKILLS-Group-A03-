/*
 * Example 043: Easing
 * A circle eases toward the mouse position (deceleration).
 * Demonstrates the easing formula: position += (target - position) * factor.
 *
 * Requires: Processing 4.x
 */

float x, y;
float easing = 0.05;

void setup() {
  size(400, 400);
  x = width / 2;
  y = height / 2;
  noStroke();
}

void draw() {
  background(30);

  float targetX = mouseX;
  float targetY = mouseY;

  x += (targetX - x) * easing;
  y += (targetY - y) * easing;

  // Trail line
  stroke(100);
  line(mouseX, mouseY, x, y);

  noStroke();
  fill(255, 200, 0);
  circle(x, y, 40);

  fill(100);
  circle(mouseX, mouseY, 10);
}
