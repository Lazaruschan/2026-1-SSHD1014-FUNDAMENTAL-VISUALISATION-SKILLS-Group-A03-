/*
 * Example 041: Moving Circle
 * A circle moves horizontally and wraps around the screen.
 * The simplest form of animation: increment position each frame.
 *
 * Requires: Processing 4.x
 */

float x = 0;
float speed = 3;

void setup() {
  size(400, 400);
  noStroke();
}

void draw() {
  background(30);

  fill(0, 180, 255);
  circle(x, height / 2, 50);

  x += speed;

  if (x > width + 25) {
    x = -25;
  }
}
