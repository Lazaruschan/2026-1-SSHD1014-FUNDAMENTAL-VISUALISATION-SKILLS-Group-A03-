/*
 * Example 048: Image Movement
 * Moves a procedurally-generated "sprite" across the screen.
 * Demonstrates animating a PGraphics object as a sprite.
 *
 * Requires: Processing 4.x
 */

PGraphics sprite;
float sx, sy;
float svx = 2, svy = 1.5;

void setup() {
  size(400, 400);

  // Create a small sprite as a PGraphics buffer
  sprite = createGraphics(40, 40);
  sprite.beginDraw();
  sprite.background(0, 0);
  sprite.noStroke();
  sprite.fill(255, 200, 0);
  sprite.ellipse(20, 20, 36, 36);
  sprite.fill(0);
  sprite.ellipse(13, 15, 6, 8);
  sprite.ellipse(27, 15, 6, 8);
  sprite.noFill();
  sprite.stroke(0);
  sprite.strokeWeight(2);
  sprite.arc(20, 24, 16, 10, 0.2, PI - 0.2);
  sprite.endDraw();

  sx = width / 2;
  sy = height / 2;
}

void draw() {
  background(30);

  sx += svx;
  sy += svy;

  if (sx < 0 || sx > width - 40)  svx *= -1;
  if (sy < 0 || sy > height - 40) svy *= -1;

  image(sprite, sx, sy);
}
