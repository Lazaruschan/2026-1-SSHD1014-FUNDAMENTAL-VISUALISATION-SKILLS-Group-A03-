/*
 * Example 045: Multiple Objects
 * Animates multiple balls with independent speeds and positions.
 * Uses arrays to manage many objects simultaneously.
 *
 * Requires: Processing 4.x
 */

int numBalls = 20;
float[] bx, by, bvx, bvy;
color[] bcolor;
float[] bsize;

void setup() {
  size(400, 400);
  noStroke();

  bx = new float[numBalls];
  by = new float[numBalls];
  bvx = new float[numBalls];
  bvy = new float[numBalls];
  bcolor = new color[numBalls];
  bsize = new float[numBalls];

  for (int i = 0; i < numBalls; i++) {
    bx[i] = random(width);
    by[i] = random(height);
    bvx[i] = random(-3, 3);
    bvy[i] = random(-3, 3);
    bcolor[i] = color(random(100, 255), random(100, 255), random(100, 255));
    bsize[i] = random(10, 30);
  }
}

void draw() {
  background(20);

  for (int i = 0; i < numBalls; i++) {
    bx[i] += bvx[i];
    by[i] += bvy[i];

    if (bx[i] < 0 || bx[i] > width) bvx[i] *= -1;
    if (by[i] < 0 || by[i] > height) bvy[i] *= -1;

    fill(bcolor[i], 200);
    circle(bx[i], by[i], bsize[i]);
  }
}
