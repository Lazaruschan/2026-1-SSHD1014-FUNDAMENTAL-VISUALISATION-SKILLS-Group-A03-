/*
 * Example 049: Particles
 * Click to emit a burst of particles that fade and fall.
 * Introduces the concept of a simple particle system using arrays.
 *
 * Requires: Processing 4.x
 */

int maxParticles = 500;
float[] px = new float[maxParticles];
float[] py = new float[maxParticles];
float[] pvx = new float[maxParticles];
float[] pvy = new float[maxParticles];
float[] plife = new float[maxParticles];
color[] pcol = new color[maxParticles];
int count = 0;

void setup() {
  size(400, 400);
  noStroke();
}

void draw() {
  background(20);

  for (int i = 0; i < count; i++) {
    pvx[i] *= 0.99;
    pvy[i] += 0.1;
    px[i] += pvx[i];
    py[i] += pvy[i];
    plife[i] -= 2;

    if (plife[i] > 0) {
      fill(pcol[i], plife[i]);
      circle(px[i], py[i], map(plife[i], 0, 255, 2, 10));
    }
  }

  // Remove dead particles by compacting
  int alive = 0;
  for (int i = 0; i < count; i++) {
    if (plife[i] > 0) {
      px[alive] = px[i]; py[alive] = py[i];
      pvx[alive] = pvx[i]; pvy[alive] = pvy[i];
      plife[alive] = plife[i]; pcol[alive] = pcol[i];
      alive++;
    }
  }
  count = alive;

  fill(255);
  textSize(14);
  textAlign(CENTER);
  text("Click to emit particles (" + count + ")", width / 2, 30);
}

void mousePressed() {
  int burst = 30;
  for (int i = 0; i < burst && count < maxParticles; i++) {
    float angle = random(TWO_PI);
    float speed = random(2, 6);
    px[count] = mouseX;
    py[count] = mouseY;
    pvx[count] = cos(angle) * speed;
    pvy[count] = sin(angle) * speed - 2;
    plife[count] = 255;
    pcol[count] = color(random(150, 255), random(80, 200), random(50, 120));
    count++;
  }
}
