/*
 * Example 046: Gravity
 * Simulates a ball falling with gravity and bouncing on the ground.
 * Demonstrates acceleration, velocity, and energy loss on bounce.
 *
 * Requires: Processing 4.x
 */

float x, y;
float vy = 0;
float gravity = 0.5;
float bounce = -0.7;
float radius = 20;

void setup() {
  size(400, 400);
  x = width / 2;
  y = 50;
  noStroke();
}

void draw() {
  background(30);

  // Ground
  fill(80);
  rect(0, height - 30, width, 30);

  // Physics
  vy += gravity;
  y += vy;

  float ground = height - 30 - radius;
  if (y > ground) {
    y = ground;
    vy *= bounce;
  }

  // Ball
  fill(255, 80, 80);
  circle(x, y, radius * 2);

  fill(255);
  textSize(14);
  textAlign(CENTER);
  text("Click to reset", width / 2, 30);
}

void mousePressed() {
  x = mouseX;
  y = 50;
  vy = 0;
}
