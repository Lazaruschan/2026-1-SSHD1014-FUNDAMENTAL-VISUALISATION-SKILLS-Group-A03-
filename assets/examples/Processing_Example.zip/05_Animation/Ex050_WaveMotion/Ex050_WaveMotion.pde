/*
 * Example 050: Wave Motion
 * Draws an animated sine wave across the screen.
 * Demonstrates sin() for continuous wave animation.
 *
 * Requires: Processing 4.x
 */

float offset = 0;

void setup() {
  size(400, 400);
}

void draw() {
  background(20);

  // Multiple wave layers
  drawWave(200, 60, 0.04, offset, color(255, 80, 80, 180));
  drawWave(200, 40, 0.06, offset * 1.3, color(80, 200, 255, 150));
  drawWave(200, 25, 0.08, offset * 0.7, color(80, 255, 120, 120));

  offset += 0.05;
}

void drawWave(float baseY, float amplitude, float frequency, float phase, color c) {
  stroke(c);
  strokeWeight(3);
  noFill();
  beginShape();
  for (int x = 0; x <= width; x += 2) {
    float y = baseY + sin(x * frequency + phase) * amplitude;
    vertex(x, y);
  }
  endShape();
}
