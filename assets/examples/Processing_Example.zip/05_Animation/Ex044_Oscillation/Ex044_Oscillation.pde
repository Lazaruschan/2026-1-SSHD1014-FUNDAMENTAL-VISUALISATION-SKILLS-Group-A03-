/*
 * Example 044: Oscillation
 * Uses sin() and cos() to create smooth oscillating motion.
 * The ball moves in a circular path using trigonometric functions.
 *
 * Requires: Processing 4.x
 */

float angle = 0;

void setup() {
  size(400, 400);
  noStroke();
}

void draw() {
  background(30);

  // Horizontal oscillation
  float x1 = width / 2 + sin(angle) * 150;
  fill(255, 100, 100);
  circle(x1, 80, 30);

  // Vertical oscillation
  float y1 = height / 2 + cos(angle) * 100;
  fill(100, 255, 100);
  circle(80, y1, 30);

  // Circular orbit
  float cx = width / 2 + cos(angle) * 100;
  float cy = height / 2 + sin(angle) * 100;
  fill(100, 100, 255);
  circle(cx, cy, 30);

  // Center marker
  fill(80);
  circle(width / 2, height / 2, 10);

  // Lissajous curve
  float lx = width / 2 + sin(angle * 2) * 80;
  float ly = 340 + cos(angle * 3) * 40;
  fill(255, 200, 50);
  circle(lx, ly, 20);

  angle += 0.03;
}
