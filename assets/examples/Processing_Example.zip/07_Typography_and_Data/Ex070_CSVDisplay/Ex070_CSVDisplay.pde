/*
 * Example 070: CSV Display
 * Parses inline CSV data and displays it as a formatted table and bar chart.
 * Demonstrates Table-like data handling with split().
 *
 * Requires: Processing 4.x
 */

String[] labels;
float[] values;

void setup() {
  size(400, 400);
  background(30);

  // Simulated CSV data (would normally use loadTable)
  String csvData = "Month,Sales\nJan,120\nFeb,150\nMar,180\nApr,220\nMay,200\nJun,260";
  String[] rows = split(csvData, '\n');

  labels = new String[rows.length - 1];
  values = new float[rows.length - 1];

  for (int i = 1; i < rows.length; i++) {
    String[] cols = split(rows[i], ',');
    labels[i - 1] = cols[0];
    values[i - 1] = float(cols[1]);
  }

  // Title
  fill(255);
  textSize(18);
  textAlign(CENTER);
  text("Monthly Sales Data", width / 2, 30);

  // Bar chart
  float maxVal = 0;
  for (float v : values) maxVal = max(maxVal, v);

  float barW = 45;
  float gap = 10;
  float startX = (width - (barW + gap) * values.length + gap) / 2;

  color[] barColors = {
    color(255, 100, 100), color(255, 180, 100), color(255, 255, 100),
    color(100, 255, 100), color(100, 200, 255), color(180, 100, 255)
  };

  for (int i = 0; i < values.length; i++) {
    float barH = map(values[i], 0, maxVal, 0, 200);
    float x = startX + i * (barW + gap);
    float y = 320 - barH;

    fill(barColors[i % barColors.length]);
    noStroke();
    rect(x, y, barW, barH, 4, 4, 0, 0);

    fill(255);
    textSize(12);
    textAlign(CENTER);
    text(labels[i], x + barW / 2, 340);
    text(nf(values[i], 0, 0), x + barW / 2, y - 8);
  }

  // Table view
  fill(150);
  textSize(11);
  textAlign(LEFT);
  text("CSV source: Month,Sales | Jan,120 | Feb,150 | ...", 20, 380);
}
