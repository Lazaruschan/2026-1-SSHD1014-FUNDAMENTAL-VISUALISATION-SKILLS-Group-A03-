/*
 * Example 063: Text Align
 * Demonstrates textAlign() for horizontal and vertical alignment.
 * LEFT, CENTER, RIGHT + TOP, CENTER, BOTTOM combinations.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(30);
  textSize(16);

  float cx = width / 2;

  // Reference line
  stroke(100);
  line(cx, 0, cx, height);

  // LEFT aligned
  fill(255, 100, 100);
  textAlign(LEFT);
  text("LEFT aligned", cx, 60);

  // CENTER aligned
  fill(100, 255, 100);
  textAlign(CENTER);
  text("CENTER aligned", cx, 120);

  // RIGHT aligned
  fill(100, 100, 255);
  textAlign(RIGHT);
  text("RIGHT aligned", cx, 180);

  // Vertical alignment demo
  float y = 280;
  stroke(100);
  line(0, y, width, y);

  textAlign(LEFT, TOP);
  fill(255, 200, 100);
  text("TOP", 20, y);

  textAlign(CENTER, CENTER);
  fill(200, 100, 255);
  text("CENTER", cx, y);

  textAlign(RIGHT, BOTTOM);
  fill(100, 255, 200);
  text("BOTTOM", width - 20, y);
}
