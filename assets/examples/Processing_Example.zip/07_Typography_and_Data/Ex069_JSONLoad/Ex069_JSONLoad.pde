/*
 * Example 069: JSON Load
 * Demonstrates creating and reading JSON data in Processing.
 * Uses JSONObject and JSONArray for structured data.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(30);

  // Create JSON data programmatically (simulating loadJSONObject)
  JSONArray students = new JSONArray();

  JSONObject s1 = new JSONObject();
  s1.setString("name", "Alice");
  s1.setInt("score", 95);
  s1.setString("grade", "A");
  students.setJSONObject(0, s1);

  JSONObject s2 = new JSONObject();
  s2.setString("name", "Bob");
  s2.setInt("score", 82);
  s2.setString("grade", "B");
  students.setJSONObject(1, s2);

  JSONObject s3 = new JSONObject();
  s3.setString("name", "Carol");
  s3.setInt("score", 91);
  s3.setString("grade", "A");
  students.setJSONObject(2, s3);

  // Display
  fill(255);
  textSize(18);
  text("JSON Student Data", 20, 40);

  textSize(14);
  for (int i = 0; i < students.size(); i++) {
    JSONObject s = students.getJSONObject(i);
    String name = s.getString("name");
    int score = s.getInt("score");
    String grade = s.getString("grade");

    float y = 80 + i * 90;
    fill(200);
    text(name + " | Grade: " + grade, 20, y);

    // Score bar
    fill(60);
    rect(20, y + 10, 300, 20);
    fill(lerpColor(color(255, 80, 80), color(80, 255, 80), score / 100.0));
    rect(20, y + 10, map(score, 0, 100, 0, 300), 20);
    fill(255);
    text(score + "/100", 330, y + 25);
  }

  fill(150);
  textSize(11);
  text("Use loadJSONObject(\"file.json\") for external files", 20, 380);
}
