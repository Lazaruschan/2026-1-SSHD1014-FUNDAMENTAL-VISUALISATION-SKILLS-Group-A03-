/*
 * Example 065: Text Wrap
 * Wraps long text within a bounding box using text(string, x, y, w, h).
 * The 5-argument version of text() enables automatic line wrapping.
 *
 * Requires: Processing 4.x
 */

String paragraph = "Processing is a flexible software sketchbook and a language for " +
  "learning how to code within the context of the visual arts. Since 2001, Processing has " +
  "promoted software literacy within the visual arts and visual literacy within technology. " +
  "There are tens of thousands of students, artists, designers, researchers, and hobbyists " +
  "who use Processing for learning and prototyping.";

void setup() {
  size(400, 400);
  background(30);

  // Bounding box
  noFill();
  stroke(100);
  rect(30, 30, 340, 200);

  // Wrapped text inside the box
  fill(255);
  textSize(14);
  textLeading(20);
  textAlign(LEFT, TOP);
  text(paragraph, 35, 35, 330, 190);

  // Smaller box
  stroke(100);
  rect(30, 260, 160, 120);
  fill(0, 200, 255);
  textSize(12);
  text(paragraph, 35, 265, 150, 110);

  fill(150);
  textSize(11);
  text("text(str, x, y, w, h) = auto wrap", 200, 280);
}
