/*
 * Example 061: Draw Text
 * Displays text on screen using text().
 * text(string, x, y) places text at the given coordinates.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(30);

  fill(255);
  textSize(32);
  text("Hello, Processing!", 30, 80);

  textSize(18);
  fill(180);
  text("text() draws strings on screen.", 30, 130);
  text("You can place text anywhere.", 30, 160);

  textSize(48);
  fill(0, 180, 255);
  text("Big!", 30, 260);

  textSize(12);
  fill(255, 200, 100);
  text("Small text for details", 30, 300);
}
