/*
 * Example 067: Load Strings
 * Demonstrates loadStrings() for reading text data.
 * Since we have no external file, we use split() on an inline string
 * to simulate the same workflow.
 *
 * Requires: Processing 4.x
 */

String[] lines;

void setup() {
  size(400, 400);
  background(30);

  // Simulating loadStrings() with inline data
  String data = "Line 1: Hello Processing\n" +
                "Line 2: loadStrings reads files\n" +
                "Line 3: Each line becomes an array element\n" +
                "Line 4: Great for reading CSV or text data\n" +
                "Line 5: Processing makes it easy";

  lines = split(data, '\n');

  fill(255);
  textSize(16);
  textAlign(LEFT, TOP);
  text("Loaded " + lines.length + " lines:", 30, 30);

  textSize(14);
  for (int i = 0; i < lines.length; i++) {
    float y = 70 + i * 30;
    fill(0, 200, 255);
    text("[" + i + "]", 30, y);
    fill(220);
    text(lines[i], 60, y);
  }

  fill(150);
  textSize(12);
  text("In practice: String[] lines = loadStrings(\"data.txt\");", 30, 300);
}
