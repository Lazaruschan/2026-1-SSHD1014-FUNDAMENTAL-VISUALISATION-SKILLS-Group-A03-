/*
 * Example 068: Split and Parse
 * Splits a CSV-like string into parts and parses numbers.
 * Demonstrates split(), trim(), int(), and float() conversions.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(30);

  String csvRow = "Alice, 92, 88.5, A";
  String[] parts = split(csvRow, ',');

  fill(255);
  textSize(16);
  text("CSV data: \"" + csvRow + "\"", 20, 40);

  textSize(14);
  text("After split(','):", 20, 80);

  for (int i = 0; i < parts.length; i++) {
    parts[i] = trim(parts[i]);
    fill(0, 200, 255);
    text("[" + i + "] = \"" + parts[i] + "\"", 40, 110 + i * 25);
  }

  // Parse numeric values
  String name = parts[0];
  int score = int(parts[1]);
  float average = float(parts[2]);
  String grade = parts[3];

  fill(255, 200, 100);
  textSize(16);
  text("Parsed values:", 20, 240);
  textSize(14);
  text("Name:    " + name, 40, 270);
  text("Score:   " + score + " (int)", 40, 295);
  text("Average: " + average + " (float)", 40, 320);
  text("Grade:   " + grade + " (String)", 40, 345);

  // Visualize score as bar
  fill(100);
  rect(40, 370, 300, 15);
  fill(0, 200, 100);
  rect(40, 370, map(score, 0, 100, 0, 300), 15);
}
