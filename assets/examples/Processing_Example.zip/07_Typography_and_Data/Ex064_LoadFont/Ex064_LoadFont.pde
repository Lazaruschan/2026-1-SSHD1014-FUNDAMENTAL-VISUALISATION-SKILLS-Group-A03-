/*
 * Example 064: Load Font
 * Uses createFont() to load a system font by name.
 * Processing can use any font installed on the system.
 *
 * Requires: Processing 4.x
 */

PFont serif;
PFont sans;
PFont mono;

void setup() {
  size(400, 400);
  background(30);

  // createFont(name, size) loads a system font
  serif = createFont("Georgia", 28);
  sans = createFont("Arial", 28);
  mono = createFont("Courier New", 22);

  fill(255);

  textFont(serif);
  text("Serif: Georgia", 30, 80);
  textSize(16);
  text("The quick brown fox jumps over the lazy dog.", 30, 110);

  textFont(sans);
  textSize(28);
  text("Sans: Arial", 30, 180);
  textSize(16);
  text("The quick brown fox jumps over the lazy dog.", 30, 210);

  textFont(mono);
  textSize(22);
  text("Mono: Courier New", 30, 280);
  textSize(14);
  text("The quick brown fox jumps", 30, 310);
  text("over the lazy dog.", 30, 330);

  fill(150);
  textFont(sans);
  textSize(12);
  text("Use createFont(\"name\", size) to load fonts", 30, 380);
}
