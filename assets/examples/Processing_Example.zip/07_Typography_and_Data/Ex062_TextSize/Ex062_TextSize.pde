/*
 * Example 062: Text Size
 * Shows text at various sizes controlled by textSize().
 * Mouse Y controls the text size dynamically.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  textAlign(CENTER, CENTER);
}

void draw() {
  background(30);

  // Static size examples
  fill(200);
  textSize(10); text("10px", 80, 60);
  textSize(16); text("16px", 80, 100);
  textSize(24); text("24px", 80, 150);
  textSize(36); text("36px", 80, 215);
  textSize(48); text("48px", 80, 290);

  // Dynamic sizing
  float sz = map(mouseY, 0, height, 8, 100);
  fill(0, 200, 255);
  textSize(sz);
  text("Resize Me", 280, height / 2);

  fill(180);
  textSize(12);
  text("Move mouse up/down", 280, height - 30);
}
