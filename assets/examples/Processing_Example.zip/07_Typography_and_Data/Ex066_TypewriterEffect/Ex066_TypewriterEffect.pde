/*
 * Example 066: Typewriter Effect
 * Reveals text one character at a time for a typewriter animation.
 * Uses substring() and frameCount to control the reveal speed.
 *
 * Requires: Processing 4.x
 */

String fullText = "Hello! Welcome to Processing.\nThis text appears one character at a time.\nPress R to restart.";
int charIndex = 0;
int speed = 3;

void setup() {
  size(400, 400);
  textSize(18);
  textLeading(28);
}

void draw() {
  background(30);

  if (frameCount % speed == 0 && charIndex < fullText.length()) {
    charIndex++;
  }

  String visible = fullText.substring(0, charIndex);

  fill(0, 255, 100);
  textAlign(LEFT, TOP);
  text(visible, 30, 30, 340, 350);

  // Blinking cursor
  if (charIndex < fullText.length() && (frameCount / 15) % 2 == 0) {
    float tw = textWidth(visible.substring(visible.lastIndexOf('\n') + 1));
    int lines = 1;
    for (int i = 0; i < charIndex; i++) {
      if (fullText.charAt(i) == '\n') lines++;
    }
    fill(0, 255, 100);
    rect(30 + tw, 30 + (lines - 1) * 28, 2, 20);
  }
}

void keyPressed() {
  if (key == 'r' || key == 'R') {
    charIndex = 0;
  }
}
