/*
 * Example 023: RGB Color
 * Demonstrates the RGB color model with three overlapping circles.
 * Red, Green, and Blue light combine to create other colors.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(0);
  noStroke();

  // Additive color mixing with transparency
  blendMode(ADD);

  fill(255, 0, 0);
  circle(160, 160, 200);

  fill(0, 255, 0);
  circle(240, 160, 200);

  fill(0, 0, 255);
  circle(200, 240, 200);

  // Reset blend mode for text
  blendMode(BLEND);
  fill(255);
  textSize(14);
  textAlign(CENTER);
  text("RGB Additive Color Mixing", width / 2, 380);
}
