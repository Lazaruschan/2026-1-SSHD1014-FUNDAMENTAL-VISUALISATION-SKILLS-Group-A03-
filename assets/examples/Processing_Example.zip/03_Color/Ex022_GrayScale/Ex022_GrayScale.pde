/*
 * Example 022: Gray Scale
 * Demonstrates grayscale values from 0 (black) to 255 (white).
 * A single value in fill() or background() sets the gray level.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(255);
  noStroke();

  int numBars = 16;
  float barWidth = width / (float) numBars;

  for (int i = 0; i < numBars; i++) {
    float gray = map(i, 0, numBars - 1, 0, 255);
    fill(gray);
    rect(i * barWidth, 0, barWidth, height / 2);
  }

  // Gray circles
  for (int i = 0; i < 10; i++) {
    float gray = map(i, 0, 9, 255, 0);
    fill(gray);
    float x = map(i, 0, 9, 40, 360);
    circle(x, 300, 35);
  }
}
