/*
 * Example 029: Random Color
 * Generates random colors using random() for each RGB channel.
 * Click the mouse to regenerate the color field.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  noStroke();
  generateColors();
}

void draw() {
}

void mousePressed() {
  generateColors();
}

void generateColors() {
  background(30);
  int cols = 10;
  int rows = 10;
  float cellW = width / (float) cols;
  float cellH = height / (float) rows;

  for (int row = 0; row < rows; row++) {
    for (int col = 0; col < cols; col++) {
      fill(random(255), random(255), random(255));
      rect(col * cellW, row * cellH, cellW, cellH);
    }
  }

  fill(255);
  textSize(12);
  textAlign(CENTER);
  text("Click to regenerate", width / 2, height - 10);
}
