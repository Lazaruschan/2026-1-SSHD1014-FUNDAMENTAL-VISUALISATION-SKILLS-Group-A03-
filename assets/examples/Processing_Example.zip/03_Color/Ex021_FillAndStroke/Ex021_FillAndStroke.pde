/*
 * Example 021: Fill and Stroke
 * Demonstrates fill() for interior color and stroke() for outlines.
 * Every shape uses the most recently set fill and stroke.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(240);

  // Red fill, black stroke
  fill(220, 50, 50);
  stroke(0);
  strokeWeight(3);
  circle(100, 100, 120);

  // Blue fill, white stroke
  fill(50, 50, 220);
  stroke(255);
  rect(180, 40, 120, 120);

  // Green fill, thick stroke
  fill(50, 180, 50);
  stroke(0, 100, 0);
  strokeWeight(6);
  triangle(100, 220, 30, 370, 170, 370);

  // Orange fill, dashed-look via thin stroke
  fill(255, 165, 0);
  stroke(150, 80, 0);
  strokeWeight(2);
  ellipse(300, 300, 150, 100);
}
