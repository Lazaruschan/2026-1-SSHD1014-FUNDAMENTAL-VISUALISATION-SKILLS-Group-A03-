/*
 * Example 024: HSB Color Mode
 * Switches to HSB (Hue, Saturation, Brightness) color mode.
 * HSB is often more intuitive than RGB for choosing colors.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  colorMode(HSB, 360, 100, 100);
  background(0, 0, 95);
  noStroke();

  // Hue spectrum bar
  for (int x = 0; x < width; x++) {
    float h = map(x, 0, width, 0, 360);
    fill(h, 90, 90);
    rect(x, 20, 1, 60);
  }

  // Saturation gradient
  for (int x = 0; x < width; x++) {
    float s = map(x, 0, width, 0, 100);
    fill(200, s, 90);
    rect(x, 120, 1, 60);
  }

  // Brightness gradient
  for (int x = 0; x < width; x++) {
    float b = map(x, 0, width, 0, 100);
    fill(200, 90, b);
    rect(x, 220, 1, 60);
  }

  fill(0, 0, 0);
  textSize(14);
  text("Hue (0-360)", 10, 15);
  text("Saturation (0-100)", 10, 115);
  text("Brightness (0-100)", 10, 215);

  // Color wheel
  float cx = 200, cy = 340;
  for (float angle = 0; angle < 360; angle += 2) {
    fill(angle, 90, 90);
    arc(cx, cy, 80, 80, radians(angle), radians(angle + 3), PIE);
  }
}
