/*
 * Example 025: Transparency
 * Demonstrates alpha (transparency) as the 4th parameter of fill().
 * Alpha 0 = fully transparent, 255 = fully opaque.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(255);
  noStroke();

  // Opaque background rectangles
  fill(200);
  rect(50, 50, 300, 300);

  // Overlapping transparent circles
  fill(255, 0, 0, 150);
  circle(150, 180, 180);

  fill(0, 0, 255, 150);
  circle(250, 180, 180);

  fill(0, 180, 0, 150);
  circle(200, 260, 180);

  // Alpha gradient bar
  for (int x = 0; x < 300; x++) {
    float a = map(x, 0, 300, 0, 255);
    fill(0, 0, 0, a);
    rect(50 + x, 370, 1, 20);
  }

  fill(0);
  textSize(12);
  text("Alpha: 0 (transparent)", 50, 365);
  textAlign(RIGHT);
  text("255 (opaque)", 350, 365);
}
