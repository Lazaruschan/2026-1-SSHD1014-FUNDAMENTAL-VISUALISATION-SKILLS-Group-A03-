/*
 * Example 027: Color Gradient
 * Creates smooth color gradients by drawing thin lines or rectangles.
 * Processing has no built-in gradient; you create them pixel by pixel.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  noStroke();

  // Horizontal gradient: blue to orange
  for (int x = 0; x < width; x++) {
    float t = x / (float) width;
    float r = lerp(30, 255, t);
    float g = lerp(100, 165, t);
    float b = lerp(230, 0, t);
    fill(r, g, b);
    rect(x, 0, 1, height / 3);
  }

  // Vertical gradient: green to purple
  for (int y = 0; y < height / 3; y++) {
    float t = y / (float) (height / 3);
    float r = lerp(50, 150, t);
    float g = lerp(200, 50, t);
    float b = lerp(50, 200, t);
    fill(r, g, b);
    rect(0, height / 3 + y, width, 1);
  }

  // Radial gradient (approximation)
  for (int radius = 200; radius > 0; radius--) {
    float t = radius / 200.0;
    fill(lerp(255, 30), lerp(50, 30), lerp(50, 200), 255);
    // Simplified: dark center to light edge
    fill(lerpColor(color(30, 30, 200), color(255, 200, 50), 1 - t));
    circle(width / 2, height / 3 * 2 + height / 6, radius * 2);
  }
}
