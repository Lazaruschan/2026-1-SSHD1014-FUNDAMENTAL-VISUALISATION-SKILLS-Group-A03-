/*
 * Example 028: Lerp Color
 * Uses lerpColor() to interpolate between two colors.
 * Great for smooth transitions and animated color changes.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
}

void draw() {
  background(30);
  noStroke();

  color c1 = color(255, 50, 50);
  color c2 = color(50, 50, 255);

  // Row of interpolated circles
  for (int i = 0; i <= 10; i++) {
    float t = i / 10.0;
    fill(lerpColor(c1, c2, t));
    float x = map(i, 0, 10, 40, 360);
    circle(x, 80, 30);
  }

  // Mouse-driven interpolation
  float mouseT = map(mouseX, 0, width, 0, 1);
  mouseT = constrain(mouseT, 0, 1);
  color c3 = color(50, 200, 50);
  color c4 = color(255, 200, 0);
  fill(lerpColor(c3, c4, mouseT));
  circle(width / 2, 250, 200);

  fill(255);
  textSize(14);
  textAlign(CENTER);
  text("Move mouse left/right to blend colors", width / 2, 370);
}
