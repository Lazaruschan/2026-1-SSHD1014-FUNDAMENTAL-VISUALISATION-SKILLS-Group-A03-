/*
 * Example 026: No Fill / No Stroke
 * Demonstrates noFill() and noStroke() to remove interior or outline.
 * Useful for wireframe drawings or flat-colored shapes.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(240);

  // Normal: fill + stroke
  fill(100, 149, 237);
  stroke(0);
  strokeWeight(3);
  circle(80, 100, 100);

  fill(0);
  textSize(11);
  text("fill + stroke", 40, 165);

  // No stroke (flat color, no outline)
  fill(237, 100, 100);
  noStroke();
  circle(200, 100, 100);

  fill(0);
  text("noStroke()", 165, 165);

  // No fill (wireframe, outline only)
  noFill();
  stroke(50, 150, 50);
  strokeWeight(3);
  circle(320, 100, 100);

  fill(0);
  noStroke();
  text("noFill()", 295, 165);

  // Concentric wireframe circles
  noFill();
  stroke(0, 100);
  strokeWeight(1);
  for (int i = 1; i <= 12; i++) {
    circle(200, 300, i * 25);
  }
}
