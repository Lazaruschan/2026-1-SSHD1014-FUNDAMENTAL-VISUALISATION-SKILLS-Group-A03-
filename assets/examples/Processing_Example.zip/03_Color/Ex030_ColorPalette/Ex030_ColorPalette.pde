/*
 * Example 030: Color Palette
 * Defines and displays a curated color palette.
 * Shows how to store colors in an array for reuse.
 *
 * Requires: Processing 4.x
 */

color[] palette;
String[] names = {
  "Coral", "Teal", "Gold", "Lavender", "Slate"
};

void setup() {
  size(400, 400);
  background(30);

  palette = new color[] {
    color(255, 127, 80),
    color(0, 128, 128),
    color(255, 215, 0),
    color(180, 130, 220),
    color(100, 120, 140)
  };

  noStroke();
  float swatchW = width / palette.length;
  float swatchH = 200;

  for (int i = 0; i < palette.length; i++) {
    fill(palette[i]);
    rect(i * swatchW, 50, swatchW, swatchH);

    // Label
    fill(255);
    textSize(12);
    textAlign(CENTER);
    text(names[i], i * swatchW + swatchW / 2, 280);
    textSize(10);
    text(hex(palette[i], 6), i * swatchW + swatchW / 2, 296);
  }

  // Composition using the palette
  fill(palette[0]);
  circle(100, 350, 40);
  fill(palette[1]);
  circle(160, 350, 40);
  fill(palette[2]);
  circle(220, 350, 40);
  fill(palette[3]);
  circle(280, 350, 40);
  fill(palette[4]);
  circle(340, 350, 40);

  fill(255);
  textSize(16);
  textAlign(CENTER);
  text("Color Palette", width / 2, 35);
}
