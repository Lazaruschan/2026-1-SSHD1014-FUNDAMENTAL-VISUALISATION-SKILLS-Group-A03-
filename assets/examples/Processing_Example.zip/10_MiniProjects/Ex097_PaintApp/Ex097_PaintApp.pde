/*
 * Example 097: Paint App
 * A simple painting application with color picker and brush sizes.
 * Press 1-5 for brush size, R/G/B/W/K for colors, C to clear.
 *
 * Requires: Processing 4.x
 */

color brushColor;
float brushSize = 8;
PGraphics canvas;

color[] palette = {
  #FF4444, #44AA44, #4444FF, #FFAA00, #FF44FF,
  #44FFFF, #FFFFFF, #888888, #000000
};
String paletteKeys = "rgboypcwk";

void setup() {
  size(400, 400);
  canvas = createGraphics(width, height - 50);
  canvas.beginDraw();
  canvas.background(255);
  canvas.endDraw();
  brushColor = color(0);
}

void draw() {
  background(40);

  if (mousePressed && mouseY < height - 50) {
    canvas.beginDraw();
    canvas.stroke(brushColor);
    canvas.strokeWeight(brushSize);
    canvas.strokeCap(ROUND);
    float my = constrain(mouseY, 0, height - 51);
    float pmy = constrain(pmouseY, 0, height - 51);
    canvas.line(pmouseX, pmy, mouseX, my);
    canvas.endDraw();
  }

  image(canvas, 0, 0);

  // Toolbar background
  fill(50);
  noStroke();
  rect(0, height - 50, width, 50);

  // Color swatches
  for (int i = 0; i < palette.length; i++) {
    fill(palette[i]);
    stroke(palette[i] == brushColor ? 255 : 80);
    strokeWeight(palette[i] == brushColor ? 2 : 1);
    rect(10 + i * 28, height - 42, 22, 22, 3);
  }

  // Brush size indicator
  fill(brushColor);
  noStroke();
  circle(330, height - 30, brushSize);

  fill(200);
  textSize(10);
  textAlign(LEFT);
  text("Size:" + (int) brushSize, 350, height - 26);
  text("C=clear", 350, height - 14);
}

void keyPressed() {
  if (key >= '1' && key <= '5') brushSize = (key - '0') * 4;
  if (key == 'c' || key == 'C') {
    canvas.beginDraw();
    canvas.background(255);
    canvas.endDraw();
  }

  int idx = paletteKeys.indexOf(Character.toLowerCase(key));
  if (idx >= 0) brushColor = palette[idx];
}

void mousePressed() {
  if (mouseY >= height - 50) {
    // Check palette clicks
    for (int i = 0; i < palette.length; i++) {
      float sx = 10 + i * 28;
      if (mouseX > sx && mouseX < sx + 22 && mouseY > height - 42 && mouseY < height - 20) {
        brushColor = palette[i];
      }
    }
  }
}
