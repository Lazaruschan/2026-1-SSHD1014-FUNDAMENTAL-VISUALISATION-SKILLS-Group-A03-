/*
 * Example 094: Particle System
 * A full particle system with emitter, gravity, wind, and fading.
 * Hold mouse to emit; press W to toggle wind.
 *
 * Requires: Processing 4.x
 */

int MAX = 1000;
float[] px = new float[MAX], py = new float[MAX];
float[] vx = new float[MAX], vy = new float[MAX];
float[] life = new float[MAX];
float[] sz = new float[MAX];
color[] pc = new color[MAX];
int count = 0;
boolean wind = false;

void setup() {
  size(400, 400);
}

void draw() {
  background(15);

  if (mousePressed && count < MAX - 5) {
    for (int i = 0; i < 5; i++) {
      float angle = random(-PI - 0.5, -HALF_PI + 0.5);
      float speed = random(2, 6);
      px[count] = mouseX;
      py[count] = mouseY;
      vx[count] = cos(angle) * speed;
      vy[count] = sin(angle) * speed;
      life[count] = 255;
      sz[count] = random(3, 10);
      pc[count] = color(
        random(200, 255),
        random(80, 200),
        random(30, 80)
      );
      count++;
    }
  }

  int alive = 0;
  for (int i = 0; i < count; i++) {
    vy[i] += 0.12;
    if (wind) vx[i] += 0.05;
    px[i] += vx[i];
    py[i] += vy[i];
    life[i] -= 1.5;

    if (life[i] > 0) {
      noStroke();
      fill(pc[i], life[i]);
      circle(px[i], py[i], sz[i] * (life[i] / 255));

      // Compact alive particles
      px[alive] = px[i]; py[alive] = py[i];
      vx[alive] = vx[i]; vy[alive] = vy[i];
      life[alive] = life[i]; sz[alive] = sz[i];
      pc[alive] = pc[i];
      alive++;
    }
  }
  count = alive;

  // HUD
  fill(200);
  textSize(12);
  textAlign(LEFT);
  text("Particles: " + count, 10, 20);
  text("Hold mouse to emit | W = wind " + (wind ? "ON" : "OFF"), 10, 38);
}

void keyPressed() {
  if (key == 'w' || key == 'W') wind = !wind;
}
