/*
 * Example 093: Typography Poster
 * Creates a bold typographic poster with layered text.
 * Demonstrates text as a graphic design element.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 560);
  background(15);
  noLoop();
}

void draw() {
  // Large background word
  fill(25);
  textSize(120);
  textAlign(CENTER, CENTER);
  pushMatrix();
  translate(width / 2, 200);
  rotate(-0.15);
  text("TYPE", 0, 0);
  popMatrix();

  // Color accent bars
  noStroke();
  fill(220, 50, 50);
  rect(0, 80, width, 8);
  fill(50, 50, 220);
  rect(0, 460, width, 8);

  // Main title
  fill(255);
  textSize(52);
  textAlign(LEFT);
  text("DESIGN", 30, 180);

  textSize(36);
  fill(220, 50, 50);
  text("WITH", 30, 225);

  textSize(72);
  fill(255);
  text("TYPE", 30, 300);

  // Body text
  textSize(12);
  fill(160);
  textLeading(18);
  text("Typography is the art and technique\nof arranging type to make written\nlanguage legible, readable, and\nappealing when displayed.", 30, 340, 200, 200);

  // Decorative numbers
  fill(255, 30);
  textSize(200);
  textAlign(RIGHT);
  text("93", width - 10, 520);

  // Footer
  fill(100);
  textSize(10);
  textAlign(CENTER);
  text("SHDS4697 / SCREEN-BASED MEDIA DESIGN", width / 2, height - 20);
}
