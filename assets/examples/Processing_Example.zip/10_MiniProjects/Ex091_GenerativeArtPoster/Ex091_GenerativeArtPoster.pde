/*
 * Example 091: Generative Art Poster
 * Creates a unique abstract poster with geometric shapes and colors.
 * Click to generate a new design. Press S to save.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 560);
  generatePoster();
}

void draw() {
}

void mousePressed() {
  generatePoster();
}

void keyPressed() {
  if (key == 's' || key == 'S') saveFrame("poster_####.png");
}

void generatePoster() {
  colorMode(HSB, 360, 100, 100);
  float baseHue = random(360);

  // Background
  background(baseHue, 10, 95);

  // Grid-based composition
  int cols = (int) random(3, 7);
  int rows = (int) random(4, 8);
  float cellW = width / (float) cols;
  float cellH = (height - 100) / (float) rows;

  noStroke();
  for (int row = 0; row < rows; row++) {
    for (int col = 0; col < cols; col++) {
      float x = col * cellW;
      float y = 60 + row * cellH;
      float hue = (baseHue + random(-40, 40) + 360) % 360;
      float sat = random(50, 100);
      float bri = random(60, 100);
      fill(hue, sat, bri);

      float chance = random(1);
      float margin = 4;
      if (chance < 0.3) {
        ellipse(x + cellW / 2, y + cellH / 2, cellW - margin * 2, cellH - margin * 2);
      } else if (chance < 0.6) {
        rect(x + margin, y + margin, cellW - margin * 2, cellH - margin * 2);
      } else if (chance < 0.8) {
        triangle(x + cellW / 2, y + margin, x + margin, y + cellH - margin, x + cellW - margin, y + cellH - margin);
      } else {
        // Empty cell
      }
    }
  }

  // Title bar
  fill(0, 0, 10);
  noStroke();
  rect(0, 0, width, 50);
  fill(0, 0, 100);
  textSize(20);
  textAlign(CENTER, CENTER);
  text("GENERATIVE #" + (int) random(1000, 9999), width / 2, 25);

  // Footer
  fill(0, 0, 30);
  rect(0, height - 40, width, 40);
  fill(0, 0, 80);
  textSize(10);
  text("SHDS4697 - Screen-Based Media Design", width / 2, height - 20);

  colorMode(RGB, 255);
}
