/*
 * Example 096: Game of Life
 * Conway's Game of Life cellular automaton.
 * Click cells to toggle alive/dead. Press SPACE to start/stop.
 *
 * Requires: Processing 4.x
 */

int cellSize = 8;
int cols, rows;
int[][] grid, next;
boolean running = false;

void setup() {
  size(400, 400);
  cols = width / cellSize;
  rows = height / cellSize;
  grid = new int[cols][rows];
  next = new int[cols][rows];

  // Random seed
  for (int c = 0; c < cols; c++)
    for (int r = 0; r < rows; r++)
      grid[c][r] = random(1) > 0.7 ? 1 : 0;
}

void draw() {
  background(15);

  for (int c = 0; c < cols; c++) {
    for (int r = 0; r < rows; r++) {
      if (grid[c][r] == 1) {
        fill(0, 200, 100);
        noStroke();
        rect(c * cellSize, r * cellSize, cellSize - 1, cellSize - 1);
      }
    }
  }

  if (running) {
    for (int c = 0; c < cols; c++) {
      for (int r = 0; r < rows; r++) {
        int neighbors = countNeighbors(c, r);
        if (grid[c][r] == 1) {
          next[c][r] = (neighbors == 2 || neighbors == 3) ? 1 : 0;
        } else {
          next[c][r] = (neighbors == 3) ? 1 : 0;
        }
      }
    }
    // Swap
    int[][] temp = grid;
    grid = next;
    next = temp;
  }

  // HUD
  fill(255, 200);
  textSize(12);
  text(running ? "Running (SPACE=pause)" : "Paused (SPACE=run, Click=draw)", 10, height - 10);
}

int countNeighbors(int c, int r) {
  int sum = 0;
  for (int dc = -1; dc <= 1; dc++) {
    for (int dr = -1; dr <= 1; dr++) {
      if (dc == 0 && dr == 0) continue;
      int nc = (c + dc + cols) % cols;
      int nr = (r + dr + rows) % rows;
      sum += grid[nc][nr];
    }
  }
  return sum;
}

void mousePressed() {
  if (!running) {
    int c = mouseX / cellSize;
    int r = mouseY / cellSize;
    if (c >= 0 && c < cols && r >= 0 && r < rows)
      grid[c][r] = 1 - grid[c][r];
  }
}

void mouseDragged() {
  if (!running) {
    int c = mouseX / cellSize;
    int r = mouseY / cellSize;
    if (c >= 0 && c < cols && r >= 0 && r < rows)
      grid[c][r] = 1;
  }
}

void keyPressed() {
  if (key == ' ') running = !running;
  if (key == 'c' || key == 'C') {
    for (int c = 0; c < cols; c++)
      for (int r = 0; r < rows; r++)
        grid[c][r] = 0;
    running = false;
  }
}
