/*
 * Example 095: Maze Generator
 * Generates a random maze using recursive backtracking.
 * Click to generate a new maze.
 *
 * Requires: Processing 4.x
 */

int cellSize = 20;
int cols, rows;
boolean[][] visited;
boolean[][][] walls;  // [col][row][0=top,1=right,2=bottom,3=left]

void setup() {
  size(400, 400);
  cols = width / cellSize;
  rows = height / cellSize;
  generateMaze();
}

void draw() {
  background(20);
  stroke(0, 200, 255);
  strokeWeight(2);

  for (int c = 0; c < cols; c++) {
    for (int r = 0; r < rows; r++) {
      float x = c * cellSize;
      float y = r * cellSize;
      if (walls[c][r][0]) line(x, y, x + cellSize, y);
      if (walls[c][r][1]) line(x + cellSize, y, x + cellSize, y + cellSize);
      if (walls[c][r][2]) line(x, y + cellSize, x + cellSize, y + cellSize);
      if (walls[c][r][3]) line(x, y, x, y + cellSize);
    }
  }

  // Start and end markers
  noStroke();
  fill(0, 255, 100);
  rect(2, 2, cellSize - 4, cellSize - 4);
  fill(255, 80, 80);
  rect((cols - 1) * cellSize + 2, (rows - 1) * cellSize + 2, cellSize - 4, cellSize - 4);
}

void mousePressed() {
  generateMaze();
}

void generateMaze() {
  visited = new boolean[cols][rows];
  walls = new boolean[cols][rows][4];
  for (int c = 0; c < cols; c++)
    for (int r = 0; r < rows; r++)
      for (int w = 0; w < 4; w++)
        walls[c][r][w] = true;

  carve(0, 0);
}

void carve(int c, int r) {
  visited[c][r] = true;
  int[] dirs = {0, 1, 2, 3};

  // Shuffle directions
  for (int i = 3; i > 0; i--) {
    int j = (int) random(i + 1);
    int temp = dirs[i]; dirs[i] = dirs[j]; dirs[j] = temp;
  }

  int[] dc = {0, 1, 0, -1};
  int[] dr = {-1, 0, 1, 0};

  for (int d : dirs) {
    int nc = c + dc[d];
    int nr = r + dr[d];
    if (nc >= 0 && nc < cols && nr >= 0 && nr < rows && !visited[nc][nr]) {
      walls[c][r][d] = false;
      walls[nc][nr][(d + 2) % 4] = false;
      carve(nc, nr);
    }
  }
}
