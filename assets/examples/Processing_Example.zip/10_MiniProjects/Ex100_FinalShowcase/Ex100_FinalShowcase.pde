/*
 * Example 100: Final Showcase
 * A grand finale combining multiple techniques: particles, noise,
 * interaction, transformations, typography, and color.
 * Press 1-4 to switch modes. Move mouse to interact.
 *
 * Requires: Processing 4.x
 */

int mode = 1;
float time = 0;

// Particle arrays
int MAX_P = 300;
float[] ppx = new float[MAX_P], ppy = new float[MAX_P];
float[] pvx = new float[MAX_P], pvy = new float[MAX_P];
float[] plife = new float[MAX_P];
int pcount = 0;

void setup() {
  size(400, 400);
}

void draw() {
  time += 0.02;

  switch (mode) {
    case 1: drawFlowMode();      break;
    case 2: drawGeometryMode();  break;
    case 3: drawTypoMode();      break;
    case 4: drawParticleMode();  break;
  }

  drawHUD();
}

// --- Mode 1: Flow Field ---
void drawFlowMode() {
  fill(15, 25);
  noStroke();
  rect(0, 0, width, height);

  for (int i = 0; i < 200; i++) {
    float x = random(width), y = random(height);
    float angle = noise(x * 0.005, y * 0.005, time) * TWO_PI * 2;
    float len = 8;
    stroke(
      map(x, 0, width, 100, 255),
      150,
      map(y, 0, height, 255, 100),
      30
    );
    strokeWeight(1);
    line(x, y, x + cos(angle) * len, y + sin(angle) * len);
  }
}

// --- Mode 2: Sacred Geometry ---
void drawGeometryMode() {
  background(10);
  translate(width / 2, height / 2);
  noFill();
  strokeWeight(1);

  for (int ring = 1; ring <= 6; ring++) {
    float radius = ring * 28;
    int sides = ring + 3;
    float rot = time * (ring % 2 == 0 ? 1 : -1) * 0.5;

    stroke(
      map(ring, 1, 6, 50, 255),
      map(ring, 1, 6, 100, 200),
      255 - ring * 30,
      180
    );

    pushMatrix();
    rotate(rot);
    beginShape();
    for (int i = 0; i < sides; i++) {
      float angle = TWO_PI / sides * i;
      vertex(cos(angle) * radius, sin(angle) * radius);
    }
    endShape(CLOSE);
    popMatrix();
  }

  // Mouse-reactive center
  float md = dist(mouseX, mouseY, width / 2, height / 2);
  float pulse = map(sin(time * 4), -1, 1, 20, 60);
  float mf = map(md, 0, 200, 1.5, 0.5);
  stroke(255, 200, 50, 200);
  strokeWeight(2);
  circle(0, 0, pulse * mf);
}

// --- Mode 3: Kinetic Typography ---
void drawTypoMode() {
  background(15);
  String word = "PROCESSING";
  textAlign(CENTER, CENTER);

  for (int i = 0; i < word.length(); i++) {
    float sz = 30 + sin(time * 3 + i * 0.5) * 15;
    float x = map(i, 0, word.length() - 1, 40, width - 40);
    float y = height / 2 + sin(time * 2 + i) * 60;

    pushMatrix();
    translate(x, y);
    rotate(sin(time + i * 0.3) * 0.3);
    textSize(sz);
    colorMode(HSB, 360, 100, 100);
    fill((time * 40 + i * 35) % 360, 80, 100);
    text(word.charAt(i), 0, 0);
    colorMode(RGB, 255);
    popMatrix();
  }
}

// --- Mode 4: Interactive Particles ---
void drawParticleMode() {
  fill(15, 30);
  noStroke();
  rect(0, 0, width, height);

  // Emit from mouse
  if (pcount < MAX_P - 3) {
    for (int i = 0; i < 3; i++) {
      float angle = random(TWO_PI);
      float speed = random(1, 4);
      ppx[pcount] = mouseX;
      ppy[pcount] = mouseY;
      pvx[pcount] = cos(angle) * speed;
      pvy[pcount] = sin(angle) * speed;
      plife[pcount] = 255;
      pcount++;
    }
  }

  int alive = 0;
  for (int i = 0; i < pcount; i++) {
    // Attract toward center
    float ax = (width / 2.0 - ppx[i]) * 0.001;
    float ay = (height / 2.0 - ppy[i]) * 0.001;
    pvx[i] += ax; pvy[i] += ay;
    pvx[i] *= 0.99; pvy[i] *= 0.99;
    ppx[i] += pvx[i];
    ppy[i] += pvy[i];
    plife[i] -= 1;

    if (plife[i] > 0) {
      colorMode(HSB, 360, 100, 100);
      float hue = (time * 60 + i * 2) % 360;
      noStroke();
      fill(hue, 80, 100, plife[i]);
      circle(ppx[i], ppy[i], map(plife[i], 0, 255, 1, 6));
      colorMode(RGB, 255);

      ppx[alive] = ppx[i]; ppy[alive] = ppy[i];
      pvx[alive] = pvx[i]; pvy[alive] = pvy[i];
      plife[alive] = plife[i];
      alive++;
    }
  }
  pcount = alive;
}

void drawHUD() {
  fill(255, 180);
  textSize(12);
  textAlign(LEFT);
  String[] modeNames = {"", "Flow Field", "Sacred Geometry", "Kinetic Type", "Particles"};
  text("Mode " + mode + ": " + modeNames[mode] + "  |  Press 1-4", 10, 20);
}

void keyPressed() {
  if (key >= '1' && key <= '4') {
    mode = key - '0';
    background(15);
    pcount = 0;
  }
}
