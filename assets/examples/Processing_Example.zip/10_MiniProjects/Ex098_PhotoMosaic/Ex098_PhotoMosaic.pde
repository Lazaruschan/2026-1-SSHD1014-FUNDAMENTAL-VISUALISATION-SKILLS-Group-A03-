/*
 * Example 098: Photo Mosaic
 * Recreates a procedural image as a mosaic of small colored tiles.
 * Each tile's color matches the average color of that region.
 *
 * Requires: Processing 4.x
 */

PImage source;
int tileSize = 10;

void setup() {
  size(400, 400);

  // Generate a procedural source image
  source = createImage(width, height, RGB);
  source.loadPixels();
  for (int x = 0; x < width; x++) {
    for (int y = 0; y < height; y++) {
      float r = 128 + 127 * sin(x * 0.03 + y * 0.01);
      float g = 128 + 127 * cos(y * 0.02);
      float b = 128 + 127 * sin((x + y) * 0.02);
      source.pixels[x + y * width] = color(r, g, b);
    }
  }
  source.updatePixels();

  renderMosaic();
}

void draw() {
}

void mousePressed() {
  tileSize = (int) random(4, 25);
  renderMosaic();
}

void renderMosaic() {
  background(0);
  noStroke();

  for (int tx = 0; tx < width; tx += tileSize) {
    for (int ty = 0; ty < height; ty += tileSize) {
      float rSum = 0, gSum = 0, bSum = 0;
      int count = 0;

      // Average color in tile region
      for (int px = tx; px < min(tx + tileSize, width); px++) {
        for (int py = ty; py < min(ty + tileSize, height); py++) {
          color c = source.pixels[px + py * width];
          rSum += red(c);
          gSum += green(c);
          bSum += blue(c);
          count++;
        }
      }

      fill(rSum / count, gSum / count, bSum / count);
      rect(tx, ty, tileSize - 1, tileSize - 1);
    }
  }

  fill(255, 200);
  textSize(12);
  text("Tile size: " + tileSize + " | Click to randomize", 10, 20);
}
