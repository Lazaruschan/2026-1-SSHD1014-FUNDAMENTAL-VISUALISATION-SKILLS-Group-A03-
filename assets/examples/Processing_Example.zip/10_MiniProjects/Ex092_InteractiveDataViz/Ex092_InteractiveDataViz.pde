/*
 * Example 092: Interactive Data Viz
 * An interactive bar chart with hover tooltips.
 * Demonstrates data visualization with mouse interaction.
 *
 * Requires: Processing 4.x
 */

String[] categories = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
float[] values = {45, 72, 58, 90, 65, 82, 38};
color[] barColors;
int hoverIndex = -1;

void setup() {
  size(400, 400);
  barColors = new color[values.length];
  for (int i = 0; i < values.length; i++) {
    barColors[i] = lerpColor(color(50, 120, 230), color(230, 80, 120), i / 6.0);
  }
}

void draw() {
  background(25);

  // Title
  fill(255);
  textSize(18);
  textAlign(CENTER);
  text("Weekly Activity", width / 2, 35);

  float chartX = 60, chartY = 60, chartW = 300, chartH = 260;
  float barW = chartW / values.length - 8;
  float maxVal = 100;

  // Y-axis grid
  stroke(50);
  textSize(10);
  textAlign(RIGHT);
  fill(120);
  for (int i = 0; i <= 4; i++) {
    float y = chartY + chartH - i * chartH / 4;
    line(chartX, y, chartX + chartW, y);
    text(nf(i * 25, 1, 0), chartX - 5, y + 4);
  }

  // Bars
  hoverIndex = -1;
  for (int i = 0; i < values.length; i++) {
    float x = chartX + i * (chartW / values.length) + 4;
    float barH = map(values[i], 0, maxVal, 0, chartH);
    float y = chartY + chartH - barH;

    boolean hover = mouseX > x && mouseX < x + barW && mouseY > y && mouseY < chartY + chartH;
    if (hover) hoverIndex = i;

    noStroke();
    fill(barColors[i], hover ? 255 : 200);
    rect(x, y, barW, barH, 3, 3, 0, 0);

    // Category label
    fill(180);
    textSize(11);
    textAlign(CENTER);
    text(categories[i], x + barW / 2, chartY + chartH + 18);
  }

  // Tooltip
  if (hoverIndex >= 0) {
    float tx = mouseX + 15, ty = mouseY - 15;
    String tip = categories[hoverIndex] + ": " + nf(values[hoverIndex], 1, 0);
    float tw = textWidth(tip) + 16;
    fill(50, 230);
    rect(tx, ty - 14, tw, 22, 4);
    fill(255);
    textSize(12);
    textAlign(LEFT);
    text(tip, tx + 8, ty + 2);
  }
}
