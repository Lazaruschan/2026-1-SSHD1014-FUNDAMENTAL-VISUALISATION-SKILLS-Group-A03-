/*
 * Example 099: Kinetic Typography
 * Animated text where each letter moves independently.
 * Demonstrates character-level text animation.
 *
 * Requires: Processing 4.x
 */

String message = "PROCESSING";
float[] offsets;
float time = 0;

void setup() {
  size(400, 400);
  offsets = new float[message.length()];
  for (int i = 0; i < offsets.length; i++) {
    offsets[i] = random(TWO_PI);
  }
}

void draw() {
  background(15);

  // Wave text
  textSize(40);
  textAlign(CENTER, CENTER);
  float totalW = 0;
  float[] charWidths = new float[message.length()];
  for (int i = 0; i < message.length(); i++) {
    charWidths[i] = textWidth(message.charAt(i));
    totalW += charWidths[i];
  }

  float startX = (width - totalW) / 2;
  float x = startX;
  for (int i = 0; i < message.length(); i++) {
    float yOff = sin(time * 3 + i * 0.5) * 30;
    float scaleF = map(sin(time * 2 + offsets[i]), -1, 1, 0.7, 1.3);
    float rotation = sin(time + offsets[i]) * 0.2;

    pushMatrix();
    translate(x + charWidths[i] / 2, 120 + yOff);
    rotate(rotation);
    scale(scaleF);

    float hue = (time * 50 + i * 30) % 360;
    colorMode(HSB, 360, 100, 100);
    fill(hue, 80, 100);
    text(message.charAt(i), 0, 0);
    colorMode(RGB, 255);
    popMatrix();

    x += charWidths[i];
  }

  // Bouncing word
  textSize(60);
  float bx = width / 2 + sin(time * 1.5) * 80;
  float by = 260 + cos(time * 2) * 30;
  fill(255, 200);
  textAlign(CENTER, CENTER);
  pushMatrix();
  translate(bx, by);
  rotate(sin(time) * 0.1);
  text("CODE", 0, 0);
  popMatrix();

  // Orbiting letters
  String orbit = "DESIGN";
  textSize(24);
  for (int i = 0; i < orbit.length(); i++) {
    float angle = TWO_PI / orbit.length() * i + time;
    float ox = width / 2 + cos(angle) * 120;
    float oy = 350 + sin(angle) * 25;
    fill(200, 200 - i * 20, 255);
    text(orbit.charAt(i), ox, oy);
  }

  time += 0.02;
}
