/*
 * Example 082: Slider UI
 * A draggable slider that controls circle size.
 * Demonstrates custom UI controls built from scratch.
 *
 * Requires: Processing 4.x
 */

float sliderX = 50, sliderY = 350, sliderW = 300;
float handleX;
boolean dragging = false;

void setup() {
  size(400, 400);
  handleX = sliderX + sliderW / 2;
}

void draw() {
  background(30);

  float value = map(handleX, sliderX, sliderX + sliderW, 10, 200);

  // Circle controlled by slider
  noStroke();
  fill(0, 180, 255);
  circle(width / 2, 180, value);

  // Slider track
  stroke(80);
  strokeWeight(4);
  line(sliderX, sliderY, sliderX + sliderW, sliderY);

  // Slider handle
  noStroke();
  fill(dragging ? color(255, 200, 0) : color(255));
  circle(handleX, sliderY, 20);

  // Label
  fill(200);
  textSize(14);
  textAlign(CENTER);
  text("Size: " + nf(value, 1, 0), width / 2, sliderY - 25);
}

void mousePressed() {
  if (dist(mouseX, mouseY, handleX, sliderY) < 15) {
    dragging = true;
  }
}

void mouseDragged() {
  if (dragging) {
    handleX = constrain(mouseX, sliderX, sliderX + sliderW);
  }
}

void mouseReleased() {
  dragging = false;
}
