/*
 * Example 083: Drag and Drop
 * Drag colored circles around the canvas with the mouse.
 * Demonstrates hit testing and object dragging.
 *
 * Requires: Processing 4.x
 */

int numCircles = 5;
float[] cx, cy;
float[] csize;
color[] ccolor;
int dragIndex = -1;
float offsetX, offsetY;

void setup() {
  size(400, 400);
  cx = new float[numCircles];
  cy = new float[numCircles];
  csize = new float[numCircles];
  ccolor = new color[numCircles];

  color[] palette = {
    color(255, 100, 100), color(100, 200, 255),
    color(255, 200, 50), color(100, 255, 150), color(200, 100, 255)
  };

  for (int i = 0; i < numCircles; i++) {
    cx[i] = random(60, width - 60);
    cy[i] = random(60, height - 60);
    csize[i] = random(40, 80);
    ccolor[i] = palette[i];
  }
}

void draw() {
  background(30);

  for (int i = 0; i < numCircles; i++) {
    noStroke();
    fill(ccolor[i], i == dragIndex ? 255 : 180);
    circle(cx[i], cy[i], csize[i]);
  }

  fill(200);
  textSize(12);
  textAlign(CENTER);
  text("Drag the circles!", width / 2, height - 15);
}

void mousePressed() {
  // Check circles in reverse order (top-most first)
  for (int i = numCircles - 1; i >= 0; i--) {
    if (dist(mouseX, mouseY, cx[i], cy[i]) < csize[i] / 2) {
      dragIndex = i;
      offsetX = cx[i] - mouseX;
      offsetY = cy[i] - mouseY;
      break;
    }
  }
}

void mouseDragged() {
  if (dragIndex >= 0) {
    cx[dragIndex] = mouseX + offsetX;
    cy[dragIndex] = mouseY + offsetY;
  }
}

void mouseReleased() {
  dragIndex = -1;
}
