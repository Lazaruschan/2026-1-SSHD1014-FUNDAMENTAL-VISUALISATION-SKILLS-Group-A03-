/*
 * Example 089: State Manager
 * Manages multiple application screens (menu, game, result).
 * Demonstrates a state machine pattern for multi-screen apps.
 *
 * Requires: Processing 4.x
 */

final int STATE_MENU = 0;
final int STATE_PLAY = 1;
final int STATE_RESULT = 2;

int state = STATE_MENU;
int score = 0;
int timer = 0;
int gameDuration = 180;

void setup() {
  size(400, 400);
  textAlign(CENTER, CENTER);
}

void draw() {
  switch (state) {
    case STATE_MENU:   drawMenu();   break;
    case STATE_PLAY:   drawPlay();   break;
    case STATE_RESULT: drawResult(); break;
  }
}

void drawMenu() {
  background(30, 40, 80);
  fill(255);
  textSize(32);
  text("Click Game", width / 2, 120);
  textSize(16);
  fill(200);
  text("Click as many times as you can\nin 3 seconds!", width / 2, 200);
  fill(0, 200, 255);
  textSize(20);
  text("[ Click to Start ]", width / 2, 320);
}

void drawPlay() {
  background(30, 60, 30);
  timer++;
  float remaining = (gameDuration - timer) / 60.0;

  if (timer >= gameDuration) {
    state = STATE_RESULT;
    return;
  }

  fill(255);
  textSize(48);
  text(score, width / 2, height / 2);

  textSize(18);
  fill(200);
  text("Time: " + nf(remaining, 1, 1) + "s", width / 2, 50);
  text("CLICK!", width / 2, height - 50);
}

void drawResult() {
  background(80, 30, 30);
  fill(255);
  textSize(24);
  text("Time's Up!", width / 2, 100);
  textSize(64);
  fill(255, 200, 0);
  text(score, width / 2, 200);
  textSize(18);
  fill(200);
  text("clicks in 3 seconds", width / 2, 260);
  fill(0, 200, 255);
  textSize(16);
  text("[ Click to Restart ]", width / 2, 340);
}

void mousePressed() {
  switch (state) {
    case STATE_MENU:
      score = 0;
      timer = 0;
      state = STATE_PLAY;
      break;
    case STATE_PLAY:
      score++;
      break;
    case STATE_RESULT:
      state = STATE_MENU;
      break;
  }
}
