/*
 * Example 087: Pixel Sort
 * Sorts pixels in each row by brightness, creating a glitch-art effect.
 * Click to regenerate the source image and re-sort.
 *
 * Requires: Processing 4.x
 */

PImage img;

void setup() {
  size(400, 400);
  generateAndSort();
}

void draw() {
  image(img, 0, 0);
  fill(255);
  textSize(12);
  text("Click to regenerate", 10, 20);
}

void mousePressed() {
  generateAndSort();
}

void generateAndSort() {
  // Generate colorful source image
  img = createImage(width, height, RGB);
  img.loadPixels();
  for (int x = 0; x < width; x++) {
    for (int y = 0; y < height; y++) {
      float n = noise(x * 0.02, y * 0.02) * 255;
      float r = n + sin(x * 0.1) * 80;
      float g = n + cos(y * 0.08) * 60;
      float b = 255 - n;
      img.pixels[x + y * width] = color(r, g, b);
    }
  }

  // Sort each row by brightness
  for (int y = 0; y < height; y++) {
    // Extract row
    color[] row = new color[width];
    for (int x = 0; x < width; x++) {
      row[x] = img.pixels[x + y * width];
    }

    // Bubble sort (small enough for demo)
    for (int i = 0; i < row.length - 1; i++) {
      for (int j = 0; j < row.length - 1 - i; j++) {
        if (brightness(row[j]) > brightness(row[j + 1])) {
          color temp = row[j];
          row[j] = row[j + 1];
          row[j + 1] = temp;
        }
      }
    }

    // Write back
    for (int x = 0; x < width; x++) {
      img.pixels[x + y * width] = row[x];
    }
  }
  img.updatePixels();
}
