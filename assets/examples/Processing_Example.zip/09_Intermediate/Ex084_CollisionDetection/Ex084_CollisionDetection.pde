/*
 * Example 084: Collision Detection
 * Detects collisions between circles and changes their color on impact.
 * Demonstrates distance-based circle-circle collision.
 *
 * Requires: Processing 4.x
 */

int num = 8;
float[] bx, by, bvx, bvy, br;
color[] bc;

void setup() {
  size(400, 400);
  bx = new float[num]; by = new float[num];
  bvx = new float[num]; bvy = new float[num];
  br = new float[num]; bc = new color[num];

  for (int i = 0; i < num; i++) {
    br[i] = random(15, 30);
    bx[i] = random(br[i], width - br[i]);
    by[i] = random(br[i], height - br[i]);
    bvx[i] = random(-2, 2);
    bvy[i] = random(-2, 2);
    bc[i] = color(100, 200, 255);
  }
}

void draw() {
  background(20);

  for (int i = 0; i < num; i++) {
    bx[i] += bvx[i]; by[i] += bvy[i];
    if (bx[i] - br[i] < 0 || bx[i] + br[i] > width) bvx[i] *= -1;
    if (by[i] - br[i] < 0 || by[i] + br[i] > height) bvy[i] *= -1;

    bc[i] = lerpColor(bc[i], color(100, 200, 255), 0.02);
  }

  // Collision check
  for (int i = 0; i < num; i++) {
    for (int j = i + 1; j < num; j++) {
      float d = dist(bx[i], by[i], bx[j], by[j]);
      if (d < br[i] + br[j]) {
        bc[i] = color(255, 80, 80);
        bc[j] = color(255, 80, 80);

        // Simple separation
        float angle = atan2(by[j] - by[i], bx[j] - bx[i]);
        float tempVx = bvx[i]; float tempVy = bvy[i];
        bvx[i] = bvx[j]; bvy[i] = bvy[j];
        bvx[j] = tempVx; bvy[j] = tempVy;
      }
    }
  }

  // Draw
  noStroke();
  for (int i = 0; i < num; i++) {
    fill(bc[i]);
    circle(bx[i], by[i], br[i] * 2);
  }
}
