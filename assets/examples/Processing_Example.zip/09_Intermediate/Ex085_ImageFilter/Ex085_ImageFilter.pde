/*
 * Example 085: Image Filter
 * Applies pixel-level filters to a procedurally generated image.
 * Press 1-4 to switch between normal, grayscale, invert, and threshold.
 *
 * Requires: Processing 4.x
 */

PImage img;
int filterMode = 0;

void setup() {
  size(400, 400);

  // Generate a colorful test image procedurally
  img = createImage(width, height, RGB);
  img.loadPixels();
  for (int x = 0; x < width; x++) {
    for (int y = 0; y < height; y++) {
      float r = map(x, 0, width, 0, 255);
      float g = map(y, 0, height, 0, 255);
      float b = map(sin(x * 0.05) * cos(y * 0.05), -1, 1, 50, 255);
      img.pixels[x + y * width] = color(r, g, b);
    }
  }
  img.updatePixels();
}

void draw() {
  PImage display = img.copy();
  display.loadPixels();

  for (int i = 0; i < display.pixels.length; i++) {
    color c = display.pixels[i];
    float r = red(c), g = green(c), b = blue(c);

    switch (filterMode) {
      case 1: // Grayscale
        float gray = 0.299 * r + 0.587 * g + 0.114 * b;
        display.pixels[i] = color(gray);
        break;
      case 2: // Invert
        display.pixels[i] = color(255 - r, 255 - g, 255 - b);
        break;
      case 3: // Threshold
        float lum = 0.299 * r + 0.587 * g + 0.114 * b;
        display.pixels[i] = lum > 128 ? color(255) : color(0);
        break;
    }
  }
  display.updatePixels();
  image(display, 0, 0);

  // Label
  fill(255);
  textSize(14);
  textAlign(LEFT);
  String[] names = {"Original", "Grayscale", "Invert", "Threshold"};
  text("Filter: " + names[filterMode] + "  (Press 1-4)", 10, 25);
}

void keyPressed() {
  if (key >= '1' && key <= '4') filterMode = key - '1';
}
