/*
 * Example 086: Mirror Effect
 * Mirrors the left half of the canvas to the right in real time.
 * Draw on the left side; the right side mirrors automatically.
 *
 * Requires: Processing 4.x
 */

PGraphics canvas;

void setup() {
  size(400, 400);
  canvas = createGraphics(width / 2, height);
  canvas.beginDraw();
  canvas.background(30);
  canvas.endDraw();
}

void draw() {
  if (mousePressed && mouseX < width / 2) {
    canvas.beginDraw();
    float hue = (frameCount * 3) % 360;
    canvas.colorMode(HSB, 360, 100, 100);
    canvas.stroke(hue, 80, 100);
    canvas.strokeWeight(4);
    float mx = constrain(mouseX, 0, width / 2.0);
    float pmx = constrain(pmouseX, 0, width / 2.0);
    canvas.line(pmx, pmouseY, mx, mouseY);
    canvas.colorMode(RGB, 255);
    canvas.endDraw();
  }

  // Draw left half
  image(canvas, 0, 0);

  // Mirror to right half
  PImage mirrored = canvas.get();
  pushMatrix();
  translate(width, 0);
  scale(-1, 1);
  image(mirrored, 0, 0);
  popMatrix();

  // Divider line
  stroke(100);
  strokeWeight(1);
  line(width / 2, 0, width / 2, height);

  fill(255);
  textSize(12);
  textAlign(CENTER);
  text("Draw on left side | Press C to clear", width / 2, height - 10);
}

void keyPressed() {
  if (key == 'c' || key == 'C') {
    canvas.beginDraw();
    canvas.background(30);
    canvas.endDraw();
  }
}
