/*
 * Example 090: Dashboard
 * A multi-widget dashboard with bar chart, line graph, and gauge.
 * Simulates live data updates using noise.
 *
 * Requires: Processing 4.x
 */

float[] history = new float[60];
int histIndex = 0;
float noiseT = 0;

void setup() {
  size(400, 400);
  for (int i = 0; i < history.length; i++) history[i] = 50;
}

void draw() {
  background(25);

  // Simulate live value
  float value = noise(noiseT) * 100;
  history[histIndex % history.length] = value;
  histIndex++;
  noiseT += 0.03;

  drawTitle();
  drawGauge(60, 60, 80, value);
  drawBarChart(200, 40, 180, 120);
  drawLineGraph(20, 220, 360, 140);
}

void drawTitle() {
  fill(255);
  textSize(14);
  textAlign(LEFT);
  text("LIVE DASHBOARD", 20, 25);
  stroke(60);
  line(20, 32, 380, 32);
}

void drawGauge(float x, float y, float r, float val) {
  pushMatrix();
  translate(x + r / 2, y + r);
  noFill();
  strokeWeight(8);
  stroke(60);
  arc(0, 0, r * 2, r * 2, PI, TWO_PI);

  float angle = map(val, 0, 100, PI, TWO_PI);
  stroke(lerpColor(color(80, 255, 80), color(255, 80, 80), val / 100.0));
  arc(0, 0, r * 2, r * 2, PI, angle);

  fill(255);
  textSize(20);
  textAlign(CENTER);
  text(nf(val, 1, 0), 0, -10);
  textSize(10);
  fill(150);
  text("VALUE", 0, 10);
  popMatrix();
}

void drawBarChart(float x, float y, float w, float h) {
  int numBars = 6;
  float barW = w / numBars - 4;
  for (int i = 0; i < numBars; i++) {
    int idx = (histIndex - numBars + i + history.length) % history.length;
    if (idx < 0) idx += history.length;
    float barH = map(history[idx], 0, 100, 0, h - 20);
    float bx = x + i * (barW + 4);
    float by = y + h - barH;

    noStroke();
    fill(0, 150, 255, 200);
    rect(bx, by, barW, barH, 2, 2, 0, 0);
  }
  fill(150);
  textSize(10);
  textAlign(LEFT);
  text("Recent Values", x, y + h + 12);
}

void drawLineGraph(float x, float y, float w, float h) {
  // Background
  fill(35);
  noStroke();
  rect(x, y, w, h, 4);

  // Grid
  stroke(50);
  for (int i = 0; i <= 4; i++) {
    float gy = y + i * h / 4;
    line(x, gy, x + w, gy);
  }

  // Line
  stroke(0, 200, 255);
  strokeWeight(2);
  noFill();
  beginShape();
  for (int i = 0; i < history.length; i++) {
    int idx = (histIndex + i) % history.length;
    float px = x + map(i, 0, history.length - 1, 5, w - 5);
    float py = y + h - map(history[idx], 0, 100, 5, h - 5);
    vertex(px, py);
  }
  endShape();

  fill(150);
  textSize(10);
  text("History (60 samples)", x + 5, y + h + 12);
}
