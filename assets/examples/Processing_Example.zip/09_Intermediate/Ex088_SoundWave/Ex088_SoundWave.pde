/*
 * Example 088: Sound Wave Visualization
 * Simulates an audio waveform visualization using noise.
 * Displays a dynamic waveform without requiring the Sound library.
 *
 * Requires: Processing 4.x
 */

float[] waveform;
int bufferSize = 200;
float noiseOffset = 0;

void setup() {
  size(400, 400);
  waveform = new float[bufferSize];
}

void draw() {
  background(20);

  // Simulate waveform using Perlin noise
  for (int i = 0; i < bufferSize; i++) {
    waveform[i] = noise(noiseOffset + i * 0.05) * 2 - 1;
    waveform[i] += sin((noiseOffset + i * 0.1) * 5) * 0.3;
  }
  noiseOffset += 0.1;

  // Waveform display
  stroke(0, 200, 255);
  strokeWeight(2);
  noFill();
  beginShape();
  for (int i = 0; i < bufferSize; i++) {
    float x = map(i, 0, bufferSize - 1, 20, width - 20);
    float y = height / 2 + waveform[i] * 100;
    vertex(x, y);
  }
  endShape();

  // Bar spectrum (simulated)
  int numBars = 32;
  float barW = (width - 40) / (float) numBars;
  for (int i = 0; i < numBars; i++) {
    float amplitude = abs(noise(noiseOffset * 0.5 + i * 0.2) - 0.3) * 2;
    float barH = amplitude * 80;
    float x = 20 + i * barW;

    noStroke();
    fill(lerpColor(color(0, 100, 255), color(255, 50, 50), amplitude));
    rect(x, height - 30 - barH, barW - 2, barH);
  }

  // Labels
  fill(150);
  textSize(12);
  textAlign(CENTER);
  text("Simulated Waveform", width / 2, 20);
  text("Simulated Spectrum", width / 2, height - 10);
}
