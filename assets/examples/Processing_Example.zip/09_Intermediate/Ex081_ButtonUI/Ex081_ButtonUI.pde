/*
 * Example 081: Button UI
 * Creates a clickable button with hover and press states.
 * Demonstrates basic UI interaction without libraries.
 *
 * Requires: Processing 4.x
 */

float btnX = 125, btnY = 160, btnW = 150, btnH = 50;
int clickCount = 0;

void setup() {
  size(400, 400);
}

void draw() {
  background(30);

  boolean hover = mouseX > btnX && mouseX < btnX + btnW &&
                  mouseY > btnY && mouseY < btnY + btnH;

  // Button
  noStroke();
  if (hover && mousePressed) {
    fill(0, 120, 200);
  } else if (hover) {
    fill(0, 160, 255);
  } else {
    fill(0, 130, 230);
  }
  rect(btnX, btnY, btnW, btnH, 8);

  fill(255);
  textSize(18);
  textAlign(CENTER, CENTER);
  text("Click Me", btnX + btnW / 2, btnY + btnH / 2);

  // Counter
  textSize(24);
  text("Count: " + clickCount, width / 2, 280);

  if (hover) cursor(HAND); else cursor(ARROW);
}

void mousePressed() {
  boolean hover = mouseX > btnX && mouseX < btnX + btnW &&
                  mouseY > btnY && mouseY < btnY + btnH;
  if (hover) clickCount++;
}
