/*
 * Example 002: Background
 * Demonstrates changing the background color each frame.
 * The background() function redraws the canvas every frame.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
}

void draw() {
  // Map mouse X position (0..width) to a hue value (0..255)
  float r = map(mouseX, 0, width, 0, 255);
  float b = map(mouseY, 0, height, 0, 255);
  background(r, 100, b);
}
