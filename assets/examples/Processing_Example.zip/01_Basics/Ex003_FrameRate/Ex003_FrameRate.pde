/*
 * Example 003: Frame Rate
 * Shows how frameRate() controls speed and frameCount tracks frames.
 * The console prints the current frame number every second.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  frameRate(30);
}

void draw() {
  background(240);

  fill(0);
  textSize(20);
  textAlign(CENTER, CENTER);
  text("Frame: " + frameCount, width / 2, height / 2 - 20);
  text("FPS: " + nf(frameRate, 1, 1), width / 2, height / 2 + 20);
}
