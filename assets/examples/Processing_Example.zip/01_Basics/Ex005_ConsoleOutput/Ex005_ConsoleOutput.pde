/*
 * Example 005: Console Output
 * Demonstrates println() for printing text and values to the console.
 * Useful for debugging and understanding program flow.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  println("Setup is running!");
  println("Window size: " + width + " x " + height);
}

void draw() {
  background(50);
  fill(255);
  textSize(18);
  textAlign(CENTER, CENTER);
  text("Check the console below!", width / 2, height / 2);

  if (frameCount % 60 == 0) {
    println("Second elapsed: " + (frameCount / 60));
  }
}
