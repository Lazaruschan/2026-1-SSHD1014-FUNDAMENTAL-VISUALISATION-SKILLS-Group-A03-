/*
 * Example 004: Coordinates
 * Draws a grid and a crosshair at the mouse position to
 * demonstrate Processing's coordinate system (origin at top-left).
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
}

void draw() {
  background(255);
  stroke(220);

  // Draw grid lines every 50 pixels
  for (int i = 0; i <= width; i += 50) {
    line(i, 0, i, height);
    line(0, i, width, i);
  }

  // Crosshair at mouse
  stroke(255, 0, 0);
  line(mouseX, 0, mouseX, height);
  line(0, mouseY, width, mouseY);

  // Coordinate label
  fill(0);
  noStroke();
  textSize(14);
  text("(" + mouseX + ", " + mouseY + ")", mouseX + 10, mouseY - 10);
}
