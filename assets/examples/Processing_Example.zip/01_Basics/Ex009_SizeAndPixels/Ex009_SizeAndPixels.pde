/*
 * Example 009: Size and Pixels
 * Demonstrates different window sizes and pixel density.
 * Draws a ruler along the edges to visualize pixel coordinates.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(600, 300);
}

void draw() {
  background(255);
  stroke(0);

  // Horizontal ruler
  for (int x = 0; x <= width; x += 50) {
    line(x, 0, x, 15);
    if (x % 100 == 0) {
      fill(0);
      textSize(10);
      textAlign(CENTER);
      text(str(x), x, 28);
    }
  }

  // Vertical ruler
  for (int y = 0; y <= height; y += 50) {
    line(0, y, 15, y);
    if (y % 100 == 0) {
      fill(0);
      textSize(10);
      textAlign(LEFT);
      text(str(y), 18, y + 4);
    }
  }

  fill(0);
  textSize(16);
  textAlign(CENTER, CENTER);
  text("Canvas: " + width + " x " + height + " pixels", width / 2, height / 2);
}
