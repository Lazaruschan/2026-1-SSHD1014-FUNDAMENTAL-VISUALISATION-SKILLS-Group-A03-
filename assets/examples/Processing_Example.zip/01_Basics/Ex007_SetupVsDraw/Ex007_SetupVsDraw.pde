/*
 * Example 007: Setup vs Draw
 * Shows the difference between setup() (runs once) and draw() (loops).
 * setup() initializes; draw() runs ~60 times per second.
 *
 * Requires: Processing 4.x
 */

int counter = 0;

void setup() {
  size(400, 400);
  println("setup() called ONCE");
  textSize(18);
  textAlign(CENTER, CENTER);
}

void draw() {
  background(245);
  counter++;

  fill(0);
  text("setup() ran once", width / 2, height / 2 - 40);
  text("draw() has run " + counter + " times", width / 2, height / 2);
  text("frameRate: " + nf(frameRate, 1, 1), width / 2, height / 2 + 40);
}
