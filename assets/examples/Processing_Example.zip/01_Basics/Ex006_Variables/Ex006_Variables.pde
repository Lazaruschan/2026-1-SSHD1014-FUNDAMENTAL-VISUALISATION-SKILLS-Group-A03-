/*
 * Example 006: Variables
 * Demonstrates declaring and using variables for position and size.
 * A circle moves across the screen using a variable.
 *
 * Requires: Processing 4.x
 */

float circleX = 0;
float circleY = 200;
float circleSize = 50;
float speed = 2;

void setup() {
  size(400, 400);
  circleY = height / 2;
}

void draw() {
  background(240);

  fill(100, 149, 237);
  noStroke();
  ellipse(circleX, circleY, circleSize, circleSize);

  circleX += speed;

  // Wrap around when off-screen
  if (circleX > width + circleSize / 2) {
    circleX = -circleSize / 2;
  }
}
