/*
 * Example 001: Hello Window
 * Creates a simple Processing window with a colored background.
 * This is the "Hello World" of Processing.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(30, 144, 255);
}

void draw() {
  // Window stays open showing the blue background
}
