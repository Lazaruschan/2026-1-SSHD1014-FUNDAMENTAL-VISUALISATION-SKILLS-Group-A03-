/*
 * Example 010: Full Screen
 * Demonstrates fullScreen() for a sketch that fills the entire display.
 * Press ESC to exit. A floating circle follows the mouse.
 *
 * Requires: Processing 4.x
 */

void setup() {
  fullScreen();
  noCursor();
}

void draw() {
  background(20);

  // Glowing circle at mouse
  noStroke();
  for (int i = 5; i > 0; i--) {
    fill(0, 150, 255, 50);
    ellipse(mouseX, mouseY, i * 30, i * 30);
  }

  fill(255);
  textSize(24);
  textAlign(CENTER, CENTER);
  text("Full Screen: " + width + " x " + height, width / 2, 40);
  textSize(16);
  text("Press ESC to exit", width / 2, 70);
}
