/*
 * Example 008: Comments
 * Demonstrates single-line and multi-line comments in Processing.
 * Good commenting practices help others (and your future self) read code.
 *
 * Requires: Processing 4.x
 */

// Single-line comment: everything after // on this line is ignored

/*
   Multi-line comment:
   Use these to explain larger blocks of logic
   or temporarily disable code.
*/

void setup() {
  size(400, 400);
  background(245);

  fill(0);
  textSize(16);
  textAlign(CENTER, CENTER);

  // This text is drawn once since there is no draw() loop
  text("Read the source code to learn\nabout comments!", width / 2, height / 2);
}
