/*
 * Example 054: Push / Pop Matrix
 * pushMatrix() saves the current transform; popMatrix() restores it.
 * This allows independent transformations for each object.
 *
 * Requires: Processing 4.x
 */

float angle = 0;

void setup() {
  size(400, 400);
  rectMode(CENTER);
}

void draw() {
  background(240);

  // Object 1: rotating square at (100, 200)
  pushMatrix();
  translate(100, 200);
  rotate(angle);
  fill(220, 60, 60);
  stroke(0);
  rect(0, 0, 60, 60);
  popMatrix();

  // Object 2: counter-rotating circle at (200, 200)
  pushMatrix();
  translate(200, 200);
  rotate(-angle * 1.5);
  fill(60, 180, 60);
  stroke(0);
  ellipse(0, -40, 30, 30);
  ellipse(0, 40, 30, 30);
  popMatrix();

  // Object 3: rotating triangle at (300, 200)
  pushMatrix();
  translate(300, 200);
  rotate(angle * 0.7);
  fill(60, 60, 220);
  stroke(0);
  triangle(0, -40, -35, 30, 35, 30);
  popMatrix();

  angle += 0.03;
}
