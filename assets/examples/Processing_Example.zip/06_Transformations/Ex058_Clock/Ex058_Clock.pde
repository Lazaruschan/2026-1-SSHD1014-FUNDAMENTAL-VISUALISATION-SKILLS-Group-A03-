/*
 * Example 058: Clock
 * Draws an analog clock using translate/rotate.
 * Hour, minute, and second hands rotate based on real time.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  strokeCap(ROUND);
}

void draw() {
  background(240);
  translate(width / 2, height / 2);

  float radius = 160;

  // Clock face
  fill(255);
  stroke(60);
  strokeWeight(4);
  circle(0, 0, radius * 2);

  // Hour markers
  for (int i = 0; i < 12; i++) {
    float angle = TWO_PI / 12 * i - HALF_PI;
    float x1 = cos(angle) * (radius - 15);
    float y1 = sin(angle) * (radius - 15);
    float x2 = cos(angle) * (radius - 5);
    float y2 = sin(angle) * (radius - 5);
    strokeWeight(i % 3 == 0 ? 4 : 2);
    stroke(0);
    line(x1, y1, x2, y2);
  }

  int h = hour() % 12;
  int m = minute();
  int s = second();

  // Hour hand
  pushMatrix();
  rotate(TWO_PI * (h + m / 60.0) / 12 - HALF_PI);
  stroke(0);
  strokeWeight(6);
  line(0, 0, 80, 0);
  popMatrix();

  // Minute hand
  pushMatrix();
  rotate(TWO_PI * (m + s / 60.0) / 60 - HALF_PI);
  stroke(40);
  strokeWeight(4);
  line(0, 0, 110, 0);
  popMatrix();

  // Second hand
  pushMatrix();
  rotate(TWO_PI * s / 60 - HALF_PI);
  stroke(220, 50, 50);
  strokeWeight(2);
  line(-15, 0, 130, 0);
  popMatrix();

  // Center dot
  fill(60);
  noStroke();
  circle(0, 0, 10);
}
