/*
 * Example 053: Scale
 * Scales drawing size using scale(). Values >1 enlarge, <1 shrink.
 * Mouse Y controls the scale factor.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  rectMode(CENTER);
}

void draw() {
  background(240);

  float s = map(mouseY, 0, height, 0.3, 3.0);

  translate(width / 2, height / 2);
  scale(s);

  fill(237, 150, 50);
  stroke(0);
  strokeWeight(2);
  rect(0, 0, 80, 80);
  fill(50, 200, 150);
  circle(0, -60, 40);

  // Scale factor label (drawn at original size in a new matrix)
  resetMatrix();
  fill(0);
  textSize(16);
  textAlign(CENTER);
  text("Scale: " + nf(s, 1, 2), width / 2, 30);
}
