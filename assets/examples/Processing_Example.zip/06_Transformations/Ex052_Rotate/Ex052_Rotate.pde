/*
 * Example 052: Rotate
 * Rotates shapes around the origin using rotate().
 * Combine with translate() to rotate around any point.
 *
 * Requires: Processing 4.x
 */

float angle = 0;

void setup() {
  size(400, 400);
  rectMode(CENTER);
}

void draw() {
  background(240);

  // Rotate around the center of the canvas
  translate(width / 2, height / 2);
  rotate(angle);

  fill(100, 149, 237);
  stroke(0);
  strokeWeight(2);
  rect(0, 0, 150, 100);

  // Reference: dot at origin
  fill(255, 0, 0);
  noStroke();
  circle(0, 0, 10);

  angle += 0.02;
}
