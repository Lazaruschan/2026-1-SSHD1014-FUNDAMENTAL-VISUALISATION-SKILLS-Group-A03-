/*
 * Example 059: Kaleidoscope
 * Creates a kaleidoscope effect by repeating a drawing with rotational symmetry.
 * Draw with the mouse; the pattern is mirrored across multiple axes.
 *
 * Requires: Processing 4.x
 */

int symmetry = 8;
PGraphics canvas;

void setup() {
  size(400, 400);
  canvas = createGraphics(400, 400);
  canvas.beginDraw();
  canvas.background(0);
  canvas.endDraw();
}

void draw() {
  if (mousePressed) {
    canvas.beginDraw();
    canvas.translate(width / 2, height / 2);

    float mx = mouseX - width / 2.0;
    float my = mouseY - height / 2.0;
    float pmx = pmouseX - width / 2.0;
    float pmy = pmouseY - height / 2.0;

    float hue = (frameCount * 2) % 360;
    canvas.colorMode(HSB, 360, 100, 100);
    canvas.stroke(hue, 80, 100, 200);
    canvas.strokeWeight(2);

    for (int i = 0; i < symmetry; i++) {
      canvas.rotate(TWO_PI / symmetry);
      canvas.line(mx, my, pmx, pmy);
      canvas.pushMatrix();
      canvas.scale(1, -1);
      canvas.line(mx, my, pmx, pmy);
      canvas.popMatrix();
    }
    canvas.colorMode(RGB, 255);
    canvas.endDraw();
  }

  image(canvas, 0, 0);

  fill(255);
  textSize(12);
  textAlign(CENTER);
  text("Draw with mouse | Press C to clear", width / 2, height - 10);
}

void keyPressed() {
  if (key == 'c' || key == 'C') {
    canvas.beginDraw();
    canvas.background(0);
    canvas.endDraw();
  }
}
