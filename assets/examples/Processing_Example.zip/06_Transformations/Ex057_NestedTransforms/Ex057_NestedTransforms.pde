/*
 * Example 057: Nested Transforms
 * Demonstrates how transformations accumulate (stack).
 * A robotic arm with segments that each rotate independently.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  strokeWeight(3);
}

void draw() {
  background(30);

  float a1 = map(mouseX, 0, width, -PI, PI);
  float a2 = map(mouseY, 0, height, -PI, PI);
  float a3 = sin(frameCount * 0.05) * HALF_PI;

  translate(width / 2, height / 2);

  // Base
  fill(80);
  stroke(200);
  circle(0, 0, 20);

  // Segment 1
  rotate(a1);
  fill(200, 80, 80);
  rect(0, -8, 80, 16, 4);

  // Segment 2 (attached to end of segment 1)
  translate(80, 0);
  fill(100);
  circle(0, 0, 14);
  rotate(a2);
  fill(80, 200, 80);
  rect(0, -6, 60, 12, 4);

  // Segment 3
  translate(60, 0);
  fill(100);
  circle(0, 0, 10);
  rotate(a3);
  fill(80, 80, 200);
  rect(0, -4, 40, 8, 4);

  // End effector
  translate(40, 0);
  fill(255, 200, 0);
  circle(0, 0, 12);
}
