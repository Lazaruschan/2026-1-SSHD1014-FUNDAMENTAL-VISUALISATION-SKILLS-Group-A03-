/*
 * Example 055: Spinning Rectangle
 * A rectangle spins around its own center at the screen center.
 * Classic example of translate-then-rotate workflow.
 *
 * Requires: Processing 4.x
 */

float angle = 0;

void setup() {
  size(400, 400);
  rectMode(CENTER);
  noStroke();
}

void draw() {
  background(20);

  // Trail effect with fading squares
  for (int i = 10; i >= 0; i--) {
    pushMatrix();
    translate(width / 2, height / 2);
    rotate(angle - i * 0.08);
    float alpha = map(i, 0, 10, 255, 20);
    float sz = map(i, 0, 10, 100, 60);
    fill(0, 150, 255, alpha);
    rect(0, 0, sz, sz);
    popMatrix();
  }

  angle += 0.04;
}
