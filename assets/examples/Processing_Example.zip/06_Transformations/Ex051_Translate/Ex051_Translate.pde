/*
 * Example 051: Translate
 * Moves the origin point using translate() before drawing.
 * Everything drawn after translate() is shifted by that amount.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
}

void draw() {
  background(240);
  stroke(0);
  strokeWeight(2);

  // Without translate: drawn at (50, 50)
  fill(200, 50, 50);
  rect(50, 50, 80, 60);

  // With translate: origin moved to mouse position
  translate(mouseX, mouseY);
  fill(50, 50, 200);
  rect(0, 0, 80, 60);

  // Everything after is also shifted
  fill(50, 200, 50);
  ellipse(40, 100, 60, 60);
}
