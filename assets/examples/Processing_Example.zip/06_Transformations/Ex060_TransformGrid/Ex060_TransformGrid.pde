/*
 * Example 060: Transform Grid
 * A grid of shapes, each individually rotated based on mouse distance.
 * Combines translate, rotate, and pushMatrix/popMatrix in a grid.
 *
 * Requires: Processing 4.x
 */

int cols = 12;
int rows = 12;

void setup() {
  size(400, 400);
  rectMode(CENTER);
}

void draw() {
  background(20);

  float cellW = width / (float) cols;
  float cellH = height / (float) rows;

  for (int row = 0; row < rows; row++) {
    for (int col = 0; col < cols; col++) {
      float cx = col * cellW + cellW / 2;
      float cy = row * cellH + cellH / 2;

      float d = dist(mouseX, mouseY, cx, cy);
      float angle = map(d, 0, 300, PI, 0);
      float sz = map(d, 0, 300, cellW * 0.8, cellW * 0.2);

      pushMatrix();
      translate(cx, cy);
      rotate(angle);

      noStroke();
      float r = map(col, 0, cols - 1, 100, 255);
      float b = map(row, 0, rows - 1, 255, 100);
      fill(r, 100, b);
      rect(0, 0, sz, sz);
      popMatrix();
    }
  }
}
