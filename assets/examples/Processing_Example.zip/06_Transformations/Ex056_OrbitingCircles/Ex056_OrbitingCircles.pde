/*
 * Example 056: Orbiting Circles
 * Multiple circles orbit around a central point at different speeds.
 * Demonstrates nested translate/rotate for orbital mechanics.
 *
 * Requires: Processing 4.x
 */

float angle = 0;

void setup() {
  size(400, 400);
  noStroke();
}

void draw() {
  background(20);

  translate(width / 2, height / 2);

  // Central "sun"
  fill(255, 200, 50);
  circle(0, 0, 40);

  // Orbit 1
  pushMatrix();
  rotate(angle);
  fill(100, 180, 255);
  circle(80, 0, 20);
  // Moon of orbit 1
  pushMatrix();
  translate(80, 0);
  rotate(angle * 3);
  fill(200);
  circle(18, 0, 8);
  popMatrix();
  popMatrix();

  // Orbit 2
  pushMatrix();
  rotate(angle * 0.6);
  fill(255, 100, 100);
  circle(140, 0, 28);
  popMatrix();

  // Orbit 3
  pushMatrix();
  rotate(-angle * 0.3);
  fill(100, 255, 150);
  circle(190, 0, 16);
  popMatrix();

  // Orbit rings (guides)
  noFill();
  stroke(60);
  strokeWeight(1);
  circle(0, 0, 160);
  circle(0, 0, 280);
  circle(0, 0, 380);

  angle += 0.02;
}
