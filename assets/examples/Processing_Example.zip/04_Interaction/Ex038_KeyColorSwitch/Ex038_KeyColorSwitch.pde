/*
 * Example 038: Key Color Switch
 * Press R, G, B keys to change the fill color of a circle.
 * Demonstrates using specific key values for actions.
 *
 * Requires: Processing 4.x
 */

color circleColor;

void setup() {
  size(400, 400);
  circleColor = color(255);
  textAlign(CENTER);
}

void draw() {
  background(30);

  noStroke();
  fill(circleColor);
  circle(width / 2, height / 2, 200);

  fill(255);
  textSize(16);
  text("Press R, G, or B to change color", width / 2, 50);

  textSize(12);
  fill(255, 80, 80);  text("[R] Red", 100, 370);
  fill(80, 255, 80);  text("[G] Green", 200, 370);
  fill(80, 80, 255);  text("[B] Blue", 300, 370);
}

void keyPressed() {
  if (key == 'r' || key == 'R') circleColor = color(220, 50, 50);
  if (key == 'g' || key == 'G') circleColor = color(50, 200, 50);
  if (key == 'b' || key == 'B') circleColor = color(50, 50, 220);
}
