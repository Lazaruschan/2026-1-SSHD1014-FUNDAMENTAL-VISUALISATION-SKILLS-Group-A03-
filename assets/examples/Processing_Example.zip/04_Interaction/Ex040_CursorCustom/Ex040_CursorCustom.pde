/*
 * Example 040: Custom Cursor
 * Hides the system cursor and draws a custom crosshair.
 * Demonstrates noCursor() and custom cursor rendering.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  noCursor();
}

void draw() {
  background(30);

  // Grid of dots that react to mouse proximity
  noStroke();
  for (int x = 20; x < width; x += 20) {
    for (int y = 20; y < height; y += 20) {
      float d = dist(mouseX, mouseY, x, y);
      float sz = map(constrain(d, 0, 100), 0, 100, 8, 2);
      float alpha = map(constrain(d, 0, 150), 0, 150, 255, 40);
      fill(100, 200, 255, alpha);
      circle(x, y, sz);
    }
  }

  // Custom crosshair cursor
  stroke(255, 100, 100);
  strokeWeight(2);
  line(mouseX - 15, mouseY, mouseX + 15, mouseY);
  line(mouseX, mouseY - 15, mouseX, mouseY + 15);
  noFill();
  circle(mouseX, mouseY, 10);
}
