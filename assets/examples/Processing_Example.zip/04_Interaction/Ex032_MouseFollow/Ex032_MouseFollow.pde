/*
 * Example 032: Mouse Follow
 * A circle follows the mouse with smooth easing movement.
 * Demonstrates linear interpolation (lerp) for smooth motion.
 *
 * Requires: Processing 4.x
 */

float posX, posY;
float easing = 0.08;

void setup() {
  size(400, 400);
  posX = width / 2;
  posY = height / 2;
  noStroke();
}

void draw() {
  background(30);

  // Ease toward mouse
  posX += (mouseX - posX) * easing;
  posY += (mouseY - posY) * easing;

  // Shadow
  fill(0, 150, 255, 60);
  circle(posX + 4, posY + 4, 50);

  // Main circle
  fill(0, 150, 255);
  circle(posX, posY, 50);
}
