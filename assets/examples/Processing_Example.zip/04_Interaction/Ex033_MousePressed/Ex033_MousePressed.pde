/*
 * Example 033: Mouse Pressed
 * Changes the background color when the mouse is clicked.
 * Demonstrates mousePressed() event and mouseButton detection.
 *
 * Requires: Processing 4.x
 */

color bgColor;

void setup() {
  size(400, 400);
  bgColor = color(30);
  textAlign(CENTER, CENTER);
  textSize(16);
}

void draw() {
  background(bgColor);

  fill(255);
  text("Left click = random color", width / 2, height / 2 - 20);
  text("Right click = reset to dark", width / 2, height / 2 + 20);
}

void mousePressed() {
  if (mouseButton == LEFT) {
    bgColor = color(random(255), random(255), random(255));
  } else if (mouseButton == RIGHT) {
    bgColor = color(30);
  }
}
