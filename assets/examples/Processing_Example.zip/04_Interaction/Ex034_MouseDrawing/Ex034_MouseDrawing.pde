/*
 * Example 034: Mouse Drawing
 * Draw on the canvas by holding the mouse button and dragging.
 * Uses pmouseX/pmouseY (previous frame mouse position) for smooth strokes.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(255);
  strokeWeight(3);
  stroke(0);
}

void draw() {
  if (mousePressed) {
    // pmouseX/pmouseY = mouse position from previous frame
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}

void keyPressed() {
  if (key == 'c' || key == 'C') {
    background(255);
  }
}
