/*
 * Example 037: Key Movement
 * Move a square around with the arrow keys (or WASD).
 * Demonstrates keyCode for special keys (UP, DOWN, LEFT, RIGHT).
 *
 * Requires: Processing 4.x
 */

float px, py;
float speed = 4;

void setup() {
  size(400, 400);
  px = width / 2;
  py = height / 2;
}

void draw() {
  background(30);

  if (keyPressed) {
    if (key == 'w' || key == 'W' || keyCode == UP)    py -= speed;
    if (key == 's' || key == 'S' || keyCode == DOWN)   py += speed;
    if (key == 'a' || key == 'A' || keyCode == LEFT)   px -= speed;
    if (key == 'd' || key == 'D' || keyCode == RIGHT)  px += speed;
  }

  // Wrap around screen
  px = (px + width) % width;
  py = (py + height) % height;

  // Draw player
  noStroke();
  fill(0, 200, 100);
  rectMode(CENTER);
  rect(px, py, 30, 30);

  fill(255);
  textSize(14);
  textAlign(CENTER);
  text("Arrow keys or WASD to move", width / 2, 30);
}
