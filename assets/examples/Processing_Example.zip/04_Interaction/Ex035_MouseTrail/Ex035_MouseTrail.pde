/*
 * Example 035: Mouse Trail
 * Leaves a fading trail of circles behind the mouse cursor.
 * Achieved by drawing a semi-transparent background each frame.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  background(20);
  noStroke();
}

void draw() {
  // Semi-transparent overlay creates the fading trail effect
  fill(20, 20, 20, 25);
  rect(0, 0, width, height);

  // Colorful circle at mouse
  float hue = (frameCount * 2) % 360;
  colorMode(HSB, 360, 100, 100);
  fill(hue, 80, 100);
  circle(mouseX, mouseY, 30);
  colorMode(RGB, 255);
}
