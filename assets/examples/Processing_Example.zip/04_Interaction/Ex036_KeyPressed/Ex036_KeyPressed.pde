/*
 * Example 036: Key Pressed
 * Responds to keyboard input. Displays the last key pressed.
 * Demonstrates keyPressed() event and the key / keyCode variables.
 *
 * Requires: Processing 4.x
 */

char lastKey = '-';
int lastKeyCode = 0;

void setup() {
  size(400, 400);
  textAlign(CENTER, CENTER);
}

void draw() {
  background(30);

  fill(255);
  textSize(24);
  text("Press any key!", width / 2, 80);

  textSize(80);
  fill(0, 200, 255);
  text(str(lastKey), width / 2, 200);

  textSize(16);
  fill(200);
  text("key: '" + lastKey + "'", width / 2, 310);
  text("keyCode: " + lastKeyCode, width / 2, 340);
}

void keyPressed() {
  lastKey = key;
  lastKeyCode = keyCode;
}
