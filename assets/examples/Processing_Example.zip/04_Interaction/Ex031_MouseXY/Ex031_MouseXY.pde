/*
 * Example 031: Mouse XY
 * Displays the current mouse position as text and a crosshair.
 * mouseX and mouseY are built-in variables updated every frame.
 *
 * Requires: Processing 4.x
 */

void setup() {
  size(400, 400);
  textSize(16);
}

void draw() {
  background(30);

  // Crosshair lines
  stroke(100);
  line(mouseX, 0, mouseX, height);
  line(0, mouseY, width, mouseY);

  // Circle at mouse
  noStroke();
  fill(0, 200, 255);
  circle(mouseX, mouseY, 20);

  // Coordinates display
  fill(255);
  textAlign(LEFT);
  text("mouseX: " + mouseX, 20, 30);
  text("mouseY: " + mouseY, 20, 55);
}
