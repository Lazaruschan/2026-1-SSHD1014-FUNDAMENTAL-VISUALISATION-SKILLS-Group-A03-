/*
 * Example 039: Mouse and Key Combined
 * Click to place circles; press 1-3 to change their size.
 * Demonstrates combining mouse and keyboard interaction.
 *
 * Requires: Processing 4.x
 */

float brushSize = 30;

void setup() {
  size(400, 400);
  background(30);
  noStroke();
  textSize(14);
}

void draw() {
  // HUD overlay
  fill(30, 200);
  rect(0, 0, width, 40);
  fill(255);
  textAlign(LEFT);
  text("Click to draw | 1=small  2=medium  3=large | Size: " + (int) brushSize, 10, 26);
}

void mousePressed() {
  fill(random(100, 255), random(100, 255), random(100, 255), 180);
  circle(mouseX, mouseY, brushSize);
}

void mouseDragged() {
  fill(random(100, 255), random(100, 255), random(100, 255), 180);
  circle(mouseX, mouseY, brushSize);
}

void keyPressed() {
  if (key == '1') brushSize = 15;
  if (key == '2') brushSize = 30;
  if (key == '3') brushSize = 60;
  if (key == 'c' || key == 'C') background(30);
}
